const API_BASE = typeof window !== 'undefined' && window.location.hostname === 'localhost' 
  ? 'http://localhost:3001' 
  : '';

export interface User {
  id: number;
  email: string;
  name?: string;
  role: 'manager' | 'employee';
  monthly_planned_hours?: number;
  is_admin?: number;
}

export interface EmployeeLog {
  user_id: number;
  user_name: string;
  total_hours: number;
}

export interface ProjectGroup {
  id: number;
  name: string;
}

export interface Project {
  id: number;
  name: string;
  project_id?: string;
  target_hours: number | null;
  assigned_to: number | null;
  is_completed?: number;
  completed_at?: string | null;
  assigned_email?: string;
  assigned_name?: string;
  actual_hours?: number;
  project_groups?: ProjectGroup[];
  employee_logs?: EmployeeLog[];
}

export type LogType = 'project' | 'vacation' | 'sick_leave' | 'article_writing' | 'presentation' | 'day_off' | 'other' | 'mandatory_training' | 'administration' | 'flat_rate_phone' | 'flat_rate_letter' | 'management_flat_rate' | 'management_expert' | 'management_other';

export interface WorkLog {
  id: number;
  user_id: number;
  project_id: number | null;
  date: string;
  hours: number;
  log_type: LogType;
}

export interface WorkLogWithProject {
  id: number;
  date: string;
  hours: number;
  project_id: number | null;
  project_name: string | null;
  log_type: LogType;
}

class ApiClient {
  private token: string | null = null;

  setToken(token: string) {
    this.token = token;
  }

  getToken() {
    return this.token;
  }

  private async fetch(endpoint: string, options: RequestInit = {}) {
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
      ...options.headers
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    const url = `${API_BASE}${endpoint}`;
    console.log(`API Request: ${options.method || 'GET'} ${url}`);

    try {
      const response = await fetch(url, {
        ...options,
        headers
      });

      if (!response.ok) {
        const error = await response.json().catch(() => ({ error: 'Unknown error' }));
        console.error(`API Error: ${response.status}`, error);
        throw new Error(error.error || `API Error: ${response.status}`);
      }

      const data = await response.json();
      return data;
    } catch (err: any) {
      console.error(`Fetch failed for ${url}:`, err);
      throw err;
    }
  }

  // Auth
  login(email: string, password: string) {
    return this.fetch('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password })
    });
  }

  switchRole(role: 'manager' | 'employee') {
    return this.fetch('/api/switch-role', {
      method: 'POST',
      body: JSON.stringify({ role })
    });
  }

  getUser() {
    return this.fetch('/api/user');
  }

  // Projects (Manager)
  createProject(name: string, project_id: string, target_hours: number | null, assigned_to: number | null, project_group_ids: number[]) {
    return this.fetch('/api/projects', {
      method: 'POST',
      body: JSON.stringify({ name, project_id, target_hours, assigned_to, project_group_ids })
    });
  }

  updateProject(id: number, name: string, target_hours: number | null, assigned_to: number | null, project_group_ids: number[]) {
    return this.fetch(`/api/projects/${id}`, {
      method: 'PUT',
      body: JSON.stringify({ name, target_hours, assigned_to, project_group_ids })
    });
  }

  deleteProject(id: number) {
    return this.fetch(`/api/projects/${id}`, {
      method: 'DELETE'
    });
  }

  getProjects() {
    return this.fetch('/api/projects');
  }

  getStatistics() {
    return this.fetch('/api/statistics');
  }

  // Employees (Manager)
  getEmployees() {
    return this.fetch('/api/employees');
  }

  createEmployee(email: string, name?: string) {
    return this.fetch('/api/employees', {
      method: 'POST',
      body: JSON.stringify({ email, name })
    });
  }

  updateEmployee(id: number, email: string, name?: string, monthly_planned_hours?: number, is_admin?: boolean) {
    return this.fetch(`/api/employees/${id}`, {
      method: 'PUT',
      body: JSON.stringify({ email, name, monthly_planned_hours, is_admin })
    });
  }

  deleteEmployee(id: number) {
    return this.fetch(`/api/employees/${id}`, {
      method: 'DELETE'
    });
  }

  resetEmployeePassword(id: number) {
    return this.fetch(`/api/employees/${id}/reset-password`, {
      method: 'POST'
    });
  }

  // Work Logs (Employee)
  getMyProjects() {
    return this.fetch('/api/my-projects');
  }

  logHours(project_id: number | null, date: string, hours: number, log_type: string = 'project', comments?: string) {
    return this.fetch('/api/logs', {
      method: 'POST',
      body: JSON.stringify({ project_id, date, hours, log_type, comments })
    });
  }

  getLogsForDate(date: string) {
    return this.fetch(`/api/logs/${date}`);
  }

  changePassword(oldPassword: string, newPassword: string) {
    return this.fetch('/api/change-password', {
      method: 'POST',
      body: JSON.stringify({ oldPassword, newPassword })
    });
  }

  // Work Logs (Employee - all logs)
  getAllLogs(startDate?: string, endDate?: string, projectId?: number) {
    let url = '/api/all-logs';
    const params = new URLSearchParams();
    if (startDate) params.append('startDate', startDate);
    if (endDate) params.append('endDate', endDate);
    if (projectId) params.append('projectId', projectId.toString());
    
    if (params.toString()) {
      url += '?' + params.toString();
    }
    
    return this.fetch(url);
  }

  updateLog(id: number, hours: number) {
    return this.fetch(`/api/logs/${id}`, {
      method: 'PUT',
      body: JSON.stringify({ hours })
    });
  }

  deleteLog(id: number) {
    return this.fetch(`/api/logs/${id}`, {
      method: 'DELETE'
    });
  }

  // Groups (Manager)
  getGroups() {
    return this.fetch('/api/groups');
  }

  createGroup(name: string, type: 'employee' | 'project', member_ids: number[]) {
    return this.fetch('/api/groups', {
      method: 'POST',
      body: JSON.stringify({ name, type, member_ids })
    });
  }

  updateGroup(id: number, name: string, member_ids: number[]) {
    return this.fetch(`/api/groups/${id}`, {
      method: 'PUT',
      body: JSON.stringify({ name, member_ids })
    });
  }

  deleteGroup(id: number) {
    return this.fetch(`/api/groups/${id}`, {
      method: 'DELETE'
    });
  }

  getStatisticsGrouped(groupId?: number) {
    let url = '/api/statistics-grouped';
    if (groupId) {
      url += `?groupId=${groupId}`;
    }
    return this.fetch(url);
  }

  getMonthlySummary(month: string): Promise<{
    logs: Array<{
      date: string;
      total_hours: number;
      available_hours: number;
    }>;
    total_available_hours: number;
  }> {
    return this.fetch(`/api/monthly-summary/${month}`);
  }

  // Project Groups (Manager)
  getProjectGroups() {
    return this.fetch('/api/project-groups');
  }

  createProjectGroup(name: string, member_ids: number[]) {
    return this.fetch('/api/project-groups', {
      method: 'POST',
      body: JSON.stringify({ name, member_ids })
    });
  }

  updateProjectGroup(id: number, name: string, member_ids: number[]) {
    return this.fetch(`/api/project-groups/${id}`, {
      method: 'PUT',
      body: JSON.stringify({ name, member_ids })
    });
  }

  deleteProjectGroup(id: number) {
    return this.fetch(`/api/project-groups/${id}`, {
      method: 'DELETE'
    });
  }

  closeProject(id: number) {
    return this.fetch(`/api/projects/${id}/close`, {
      method: 'POST'
    });
  }

  reopenProject(id: number) {
    return this.fetch(`/api/projects/${id}/reopen`, {
      method: 'POST'
    });
  }

  getEmployeeProjects() {
    return this.fetch('/api/employee-projects');
  }

  // Employee monthly summary (Manager)
  getEmployeeMonthlySummary(employeeId: number, month: string): Promise<{
    logs: Array<{
      date: string;
      total_hours: number;
      available_hours: number;
    }>;
    total_available_hours: number;
  }> {
    return this.fetch(`/api/employees/${employeeId}/monthly-summary/${month}`);
  }

  // Employee all logs (Manager)
  getEmployeeAllLogs(employeeId: number, startDate?: string, endDate?: string, projectId?: number) {
    let url = `/api/employees/${employeeId}/all-logs`;
    const params = new URLSearchParams();
    if (startDate) params.append('startDate', startDate);
    if (endDate) params.append('endDate', endDate);
    if (projectId) params.append('projectId', projectId.toString());
    
    if (params.toString()) {
      url += '?' + params.toString();
    }
    
    return this.fetch(url);
  }
}

export const api = new ApiClient();
