import { api, type User } from './api';

const TOKEN_KEY = 'munkido_token';
const USER_KEY = 'munkido_user';

export function saveAuth(token: string, user: User) {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(USER_KEY, JSON.stringify(user));
  api.setToken(token);
}

export function getAuth() {
  const token = localStorage.getItem(TOKEN_KEY);
  const userStr = localStorage.getItem(USER_KEY);
  
  if (token && userStr) {
    const user = JSON.parse(userStr);
    api.setToken(token);
    return { token, user };
  }

  return null;
}

export function clearAuth() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
  api.setToken('');
}
