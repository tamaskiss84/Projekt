import { useState, useEffect } from 'react';
import { Card } from '../components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { api, type ProjectGroup } from '../lib/api';

interface EmployeeLog {
  user_id: number;
  user_name: string;
  total_hours: number;
}

interface Project {
  id: number;
  name: string;
  project_id?: string;
  target_hours: number | null;
  is_completed?: number;
  project_groups?: ProjectGroup[];
  employee_logs?: {
    user_id: number;
    user_name: string;
    total_hours: number;
  }[];
}

export function ProjectsTab() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [activeTab, setActiveTab] = useState<'active' | 'completed'>('active');
  const [loading, setLoading] = useState(true);
  const [projectGroups, setProjectGroups] = useState<ProjectGroup[]>([]);
  const [selectedGroupId, setSelectedGroupId] = useState<number | null>(null);

  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = async () => {
    try {
      setLoading(true);
      const data = await api.getMyProjects();
      setProjects(data);
      
      const groupsMap = new Map<number, ProjectGroup>();
      data.forEach(project => {
        if (project.project_groups) {
          project.project_groups.forEach(group => {
            if (!groupsMap.has(group.id)) {
              groupsMap.set(group.id, group);
            }
          });
        }
      });
      setProjectGroups(Array.from(groupsMap.values()));
    } catch (err) {
      console.error('Error loading projects:', err);
    } finally {
      setLoading(false);
    }
  };

  const exportToCSV = () => {
    const csvContent: string[] = [];
    csvContent.push('Projekt név,Projekt csoportok,Tervezett óraszám,Dolgozó,Ledolgozott órák');

    displayProjects.forEach(project => {
      const projectGroups = project.project_groups?.map(g => g.name).join('; ') || '-';
      const targetHours = project.target_hours !== null ? project.target_hours.toString() : 'Nincs óraszám';
      
      if (project.employee_logs && project.employee_logs.length > 0) {
        project.employee_logs.forEach(log => {
          csvContent.push(`"${project.name}","${projectGroups}","${targetHours}","${log.user_name}","${log.total_hours}"`);
        });
        const totalHours = project.employee_logs.reduce((sum, log) => sum + log.total_hours, 0);
        csvContent.push(`"${project.name}","${projectGroups}","${targetHours}","Összesen","${totalHours}"`);
      } else {
        csvContent.push(`"${project.name}","${projectGroups}","${targetHours}","",""`);
      }
    });

    const csv = csvContent.join('\n');
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', `projektek_${activeTab}_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading) {
    return (
      <Card className="p-6">
        <p className="text-gray-600">Betöltés...</p>
      </Card>
    );
  }

  let activeProjects = projects.filter(p => !p.is_completed);
  let completedProjects = projects.filter(p => p.is_completed);

  if (selectedGroupId !== null) {
    activeProjects = activeProjects.filter(p => 
      p.project_groups?.some(g => g.id === selectedGroupId)
    );
    completedProjects = completedProjects.filter(p => 
      p.project_groups?.some(g => g.id === selectedGroupId)
    );
  }

  if (projects.length === 0) {
    return (
      <Card className="p-6 text-center">
        <p className="text-gray-600 mb-4">Nincs elérhető projekt.</p>
        <p className="text-sm text-gray-500">
          Vedd fel a kapcsolatot a vezetővel projekt csoport hozzárendeléséhez.
        </p>
      </Card>
    );
  }

  const displayProjects = activeTab === 'active' ? activeProjects : completedProjects;

  return (
    <div className="space-y-4">
      <Card className="p-4">
        <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center">
          <div className="flex gap-2 overflow-x-auto w-full sm:w-auto">
            <button
              onClick={() => setActiveTab('active')}
              className={`px-4 py-2 text-sm font-medium rounded-lg transition whitespace-nowrap ${
                activeTab === 'active'
                  ? 'bg-gradient-to-r from-sky-500 to-blue-500 text-white shadow-md'
                  : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50 hover:border-sky-300'
              }`}
            >
              Aktív projektek ({activeProjects.length})
            </button>
            <button
              onClick={() => setActiveTab('completed')}
              className={`px-4 py-2 text-sm font-medium rounded-lg transition whitespace-nowrap ${
                activeTab === 'completed'
                  ? 'bg-gradient-to-r from-sky-500 to-blue-500 text-white shadow-md'
                  : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50 hover:border-sky-300'
              }`}
            >
              Befejezett projektek ({completedProjects.length})
            </button>
          </div>
          
          {projectGroups.length > 0 && (
            <div className="flex items-center gap-2 w-full sm:w-auto sm:ml-auto">
              <label className="text-sm font-medium text-gray-700 whitespace-nowrap">
                Szűrés:
              </label>
              <Select
                value={selectedGroupId?.toString() ?? "all"}
                onValueChange={(value) => setSelectedGroupId(value === "all" ? null : Number(value))}
              >
                <SelectTrigger className="w-full sm:w-[240px]">
                  <SelectValue placeholder="Összes projektcsoport" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Összes projektcsoport</SelectItem>
                  {projectGroups.map(group => (
                    <SelectItem key={group.id} value={group.id.toString()}>
                      {group.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
        </div>
      </Card>

      <Card className="p-4 sm:p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold text-gray-900">
            {displayProjects.length} projekt
          </h2>
          {displayProjects.length > 0 && (
            <button
              onClick={exportToCSV}
              className="px-4 py-2 text-sm bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition flex items-center gap-2"
            >
              <span>📥</span>
              <span>Export CSV</span>
            </button>
          )}
        </div>

        {displayProjects.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-gray-600">
              {selectedGroupId !== null 
                ? 'Nincs projekt ebben a projektcsoportban.'
                : activeTab === 'active' ? 'Nincs aktív projekt.' : 'Nincs befejezett projekt.'}
            </p>
          </div>
        ) : (
          <div className="space-y-3 sm:space-y-4">
            {displayProjects.map((project) => (
              <div key={project.id} className="p-3 sm:p-4 bg-gray-50 rounded-lg">
                <div className="mb-3">
                  {project.project_id && (
                    <p className="text-xs sm:text-sm text-indigo-600 font-semibold">{project.project_id}</p>
                  )}
                  <h3 className="font-semibold text-base sm:text-lg">{project.name}</h3>
                </div>
                
                <div className="mb-3">
                  <div>
                    <p className="text-xs sm:text-sm text-gray-500">Projekt csoportok</p>
                    <p className="font-medium text-sm sm:text-base">
                      {project.project_groups && project.project_groups.length > 0
                        ? project.project_groups.map(g => g.name).join(', ')
                        : '-'}
                    </p>
                  </div>
                </div>

                {project.employee_logs && project.employee_logs.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-gray-200">
                    <p className="text-sm font-medium text-gray-700 mb-2">Dolgozók órái:</p>
                    <div className="space-y-1">
                      {project.employee_logs.map((log) => (
                        <div key={log.user_id} className="flex justify-between text-sm">
                          <span>{log.user_name}</span>
                          <span className="font-semibold text-indigo-600">{log.total_hours} óra</span>
                        </div>
                      ))}
                      <div className="flex justify-between text-sm font-bold border-t border-gray-300 pt-2 mt-2">
                        <span>Összesen:</span>
                        <span className="text-indigo-700">
                          {project.employee_logs.reduce((sum, log) => sum + log.total_hours, 0)} óra
                        </span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
