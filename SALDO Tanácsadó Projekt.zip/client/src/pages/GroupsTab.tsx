import { useState, useEffect } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card } from '../components/ui/card';
import { api, type Project, type User } from '../lib/api';

interface Group {
  id: number;
  name: string;
  type: 'employee' | 'project';
  member_ids: number[];
}

interface GroupsTabProps {
  employees: User[];
  projects: Project[];
}

export function GroupsTab({ employees, projects }: GroupsTabProps) {
  const [groups, setGroups] = useState<Group[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const [groupName, setGroupName] = useState('');
  const [groupType, setGroupType] = useState<'employee' | 'project'>('employee');
  const [selectedMembers, setSelectedMembers] = useState<number[]>([]);
  const [editingGroup, setEditingGroup] = useState<Group | null>(null);

  useEffect(() => {
    loadGroups();
  }, []);

  const loadGroups = async () => {
    try {
      setLoading(true);
      setError('');
      const data = await api.getGroups();
      setGroups(data);
    } catch (err) {
      setError('Hiba a csoportok betöltésekor');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!groupName || selectedMembers.length === 0) {
      setError('Add meg a csoport nevét és válassz tagokat!');
      return;
    }

    try {
      setLoading(true);
      setError('');
      await api.createGroup(groupName, groupType, selectedMembers);
      setGroupName('');
      setSelectedMembers([]);
      await loadGroups();
    } catch (err) {
      setError('Hiba a csoport létrehozásakor');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingGroup || !groupName || selectedMembers.length === 0) {
      setError('Add meg a csoport nevét és válassz tagokat!');
      return;
    }

    try {
      setLoading(true);
      setError('');
      await api.updateGroup(editingGroup.id, groupName, selectedMembers);
      setGroupName('');
      setSelectedMembers([]);
      setEditingGroup(null);
      await loadGroups();
    } catch (err) {
      setError('Hiba a csoport módosításakor');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleEditGroup = (group: Group) => {
    setEditingGroup(group);
    setGroupName(group.name);
    setGroupType(group.type);
    setSelectedMembers(group.member_ids);
  };

  const handleCancelEdit = () => {
    setEditingGroup(null);
    setGroupName('');
    setSelectedMembers([]);
    setGroupType('employee');
  };

  const handleDeleteGroup = async (group: Group) => {
    if (!window.confirm(`Biztosan törlöd a következő csoportot: ${group.name}?`)) {
      return;
    }

    try {
      setLoading(true);
      setError('');
      await api.deleteGroup(group.id);
      await loadGroups();
    } catch (err) {
      setError('Hiba a csoport törlésekor');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const toggleMember = (memberId: number) => {
    if (selectedMembers.includes(memberId)) {
      setSelectedMembers(selectedMembers.filter(id => id !== memberId));
    } else {
      setSelectedMembers([...selectedMembers, memberId]);
    }
  };

  const availableMembers = groupType === 'employee' ? employees : projects;

  const getMemberName = (memberId: number, type: 'employee' | 'project') => {
    if (type === 'employee') {
      return employees.find(e => e.id === memberId)?.name || 'Ismeretlen';
    } else {
      return projects.find(p => p.id === memberId)?.name || 'Ismeretlen';
    }
  };

  return (
    <div className="space-y-8">
      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
          {error}
        </div>
      )}

      <Card className="p-6">
        <h2 className="text-xl font-bold mb-6">
          {editingGroup ? 'Csoport szerkesztése' : 'Új csoport létrehozása'}
        </h2>
        <form onSubmit={editingGroup ? handleUpdateGroup : handleCreateGroup} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Csoport neve
            </label>
            <Input
              type="text"
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
              placeholder="Csoport neve"
              disabled={loading}
            />
          </div>

          {!editingGroup && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Csoport típusa
              </label>
              <select
                value={groupType}
                onChange={(e) => {
                  setGroupType(e.target.value as 'employee' | 'project');
                  setSelectedMembers([]);
                }}
                className="flex h-9 w-full items-center justify-between rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm ring-offset-background focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
                disabled={loading}
              >
                <option value="employee">Dolgozó csoport</option>
              </select>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {groupType === 'employee' ? 'Dolgozók' : 'Projektek'} ({selectedMembers.length} kiválasztva)
            </label>
            <div className="border border-gray-200 rounded-lg p-4 max-h-64 overflow-y-auto">
              {availableMembers.length === 0 ? (
                <p className="text-gray-500 text-sm">
                  Nincs elérhető {groupType === 'employee' ? 'dolgozó' : 'projekt'}
                </p>
              ) : (
                <div className="space-y-2">
                  {availableMembers.map((member) => (
                    <label
                      key={member.id}
                      className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-2 rounded"
                    >
                      <input
                        type="checkbox"
                        checked={selectedMembers.includes(member.id)}
                        onChange={() => toggleMember(member.id)}
                        className="rounded border-gray-300"
                      />
                      <span className="text-sm">
                        {'email' in member ? member.name : member.name}
                      </span>
                    </label>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="flex gap-2">
            <Button
              type="submit"
              className="bg-indigo-600 hover:bg-indigo-700 flex-1"
              disabled={loading}
            >
              {loading ? 'Betöltés...' : editingGroup ? 'Módosítás mentése' : 'Csoport mentése'}
            </Button>
            {editingGroup && (
              <Button
                type="button"
                onClick={handleCancelEdit}
                className="bg-gray-600 hover:bg-gray-700"
                disabled={loading}
              >
                Mégse
              </Button>
            )}
          </div>
        </form>
      </Card>

      <Card className="p-6">
        <h2 className="text-xl font-bold mb-6">Csoportok listája</h2>
        {groups.length === 0 ? (
          <p className="text-gray-600">Még nincs létrehozott csoport.</p>
        ) : (
          <div className="space-y-4">
            {groups.map((group) => (
              <div
                key={group.id}
                className="border border-gray-200 rounded-lg p-4"
              >
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-semibold text-gray-900">{group.name}</h3>
                    <p className="text-sm text-gray-600">
                      {group.type === 'employee' ? 'Dolgozó csoport' : 'Projekt csoport'} - {group.member_ids.length} tag
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => handleEditGroup(group)}
                      className="bg-blue-600 hover:bg-blue-700 text-sm px-3 py-1"
                      disabled={loading}
                    >
                      Szerkeszt
                    </Button>
                    <Button
                      onClick={() => handleDeleteGroup(group)}
                      className="bg-red-600 hover:bg-red-700 text-sm px-3 py-1"
                      disabled={loading}
                    >
                      Törlés
                    </Button>
                  </div>
                </div>
                <div className="mt-3">
                  <p className="text-sm font-medium text-gray-700 mb-1">Tagok:</p>
                  <div className="flex flex-wrap gap-2">
                    {group.member_ids.map((memberId) => (
                      <span
                        key={memberId}
                        className="inline-block bg-gray-100 text-gray-700 text-xs px-2 py-1 rounded"
                      >
                        {getMemberName(memberId, group.type)}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
