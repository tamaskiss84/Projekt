import { Card } from '../components/ui/card';
import { Progress } from '../components/ui/progress';
import { Project } from '../lib/api';

interface ProjectsListProps {
  projects: Project[];
  loading: boolean;
  isAdmin?: boolean;
  onEdit?: (project: Project) => void;
  onDelete?: (project: Project) => void;
  onClose?: (project: Project) => void;
}

export function ProjectsList({ projects, loading, isAdmin = false, onEdit, onDelete, onClose }: ProjectsListProps) {
  if (loading && projects.length === 0) {
    return (
      <Card className="p-6">
        <p className="text-gray-600">Betöltés...</p>
      </Card>
    );
  }

  if (projects.length === 0) {
    return (
      <Card className="p-6">
        <p className="text-gray-600">Még nincs projekt.</p>
      </Card>
    );
  }

  function handleEdit(project: Project) {
    if (onEdit) {
      onEdit(project);
    }
  }

  function handleDelete(project: Project) {
    if (onDelete) {
      onDelete(project);
    }
  }

  function handleClose(project: Project) {
    if (onClose) {
      onClose(project);
    }
  }

  return (
    <Card className="p-4 sm:p-6">
      <h2 className="text-lg sm:text-xl font-bold mb-4 sm:mb-6 text-gray-900">Aktív projektek állása</h2>
      <div className="space-y-4 sm:space-y-6">
        {projects.map((project) => {
          const progress = project.target_hours && project.actual_hours ? project.actual_hours / project.target_hours : 0;
          const percentage = Math.min(progress * 100, 100);

          return (
            <div
              key={project.id}
              className="border border-gray-200 rounded-lg p-3 sm:p-4 hover:border-indigo-300 transition bg-white"
            >
              <div className="flex flex-col sm:flex-row justify-between items-start gap-3 sm:gap-4 mb-2">
                <div className="flex-1">
                  {project.project_id && (
                    <p className="text-xs sm:text-sm text-indigo-600 font-semibold">{project.project_id}</p>
                  )}
                  <p className="text-xs sm:text-sm text-gray-500">Projekt neve</p>
                  <p className="font-medium text-sm sm:text-base">{project.name}</p>
                  <p className="text-xs text-gray-400 mt-1">
                    Csoportok: {project.project_groups && project.project_groups.length > 0
                      ? project.project_groups.map(g => g.name).join(', ')
                      : '-'}
                  </p>
                </div>
                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4 w-full sm:w-auto">
                  <div className="text-left sm:text-right">
                    <p className="font-semibold text-gray-900 text-sm sm:text-base">
                      {project.actual_hours?.toFixed(1) || 0} {project.target_hours !== null ? `/ ${project.target_hours} óra` : 'óra'}
                    </p>
                    {project.target_hours !== null && (
                      <p className="text-xs sm:text-sm text-gray-700">{percentage.toFixed(0)}%</p>
                    )}
                  </div>
                  {isAdmin && (
                    <div className="flex gap-2 flex-wrap w-full sm:w-auto">
                      <button
                        onClick={() => handleEdit(project)}
                        className="px-2 sm:px-3 py-1 text-xs sm:text-sm bg-sky-600 text-white rounded hover:bg-sky-700 transition shadow-sm"
                      >
                        Szerkesztés
                      </button>
                      <button
                        onClick={() => handleClose(project)}
                        className="px-2 sm:px-3 py-1 text-xs sm:text-sm bg-green-600 text-white rounded hover:bg-green-700 transition"
                      >
                        Lezárás
                      </button>
                      <button
                        onClick={() => handleDelete(project)}
                        className="px-2 sm:px-3 py-1 text-xs sm:text-sm bg-red-600 text-white rounded hover:bg-red-700 transition"
                      >
                        Törlés
                      </button>
                    </div>
                  )}
                </div>
              </div>
              {project.target_hours !== null && (
                <Progress value={percentage} className="h-2" />
              )}
              
              {project.employee_logs && project.employee_logs.length > 0 && (
                <div className="mt-4 pt-4 border-t border-gray-200">
                  <p className="text-sm font-semibold text-gray-700 mb-2">Dolgozók órái:</p>
                  <div className="space-y-1">
                    {project.employee_logs.map((log) => (
                      <div key={log.user_id} className="flex justify-between text-sm">
                        <span className="text-gray-600">{log.user_name}</span>
                        <span className="font-medium text-gray-900">{log.total_hours.toFixed(1)} óra</span>
                      </div>
                    ))}
                    <div className="flex justify-between text-sm font-semibold pt-2 border-t border-gray-100">
                      <span className="text-gray-700">Összesen:</span>
                      <span className="text-gray-900">{project.actual_hours?.toFixed(1) || 0} óra</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </Card>
  );
}
