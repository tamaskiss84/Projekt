import { useState, useEffect } from 'react';
import { Card } from '../components/ui/card';
import { Progress } from '../components/ui/progress';
import { api, type Project } from '../lib/api';
import { BarChart, Bar, PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LabelList } from 'recharts';

// @ts-ignore - Recharts type compatibility issue with React 18
const RechartsContainer = ResponsiveContainer as any;
const RechartsBarChart = BarChart as any;
const RechartsPieChart = PieChart as any;
const RechartsLineChart = LineChart as any;
const RechartsXAxis = XAxis as any;
const RechartsYAxis = YAxis as any;
const RechartsBar = Bar as any;
const RechartsLine = Line as any;
const RechartsCell = Cell as any;
const RechartsPie = Pie as any;
const RechartsCartesianGrid = CartesianGrid as any;
const RechartsTooltip = Tooltip as any;
const RechartsLegend = Legend as any;
const RechartsLabelList = LabelList as any;

interface ProjectStat {
  id: number;
  name: string;
  target_hours: number;
  actual_hours: number;
  progress: number;
  remaining: number;
}

interface EmployeeStat {
  employee_id: number;
  employee_name: string;
  total_hours: number;
  project_count: number;
  projects: any[];
}

interface EmployeeGroup {
  id: number;
  name: string;
  member_ids: number[];
}

export function StatisticsTab() {
  const [statistics, setStatistics] = useState<ProjectStat[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedGroup, setSelectedGroup] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [viewMode, setViewMode] = useState<'projects' | 'employees'>('projects');
  const [employeeStats, setEmployeeStats] = useState<EmployeeStat[]>([]);
  const [chartType, setChartType] = useState<'bar' | 'pie' | 'line'>('bar');
  const [sortBy, setSortBy] = useState<'name' | 'progress' | 'hours'>('progress');
  const [filterStatus, setFilterStatus] = useState<'all' | 'completed' | 'inProgress' | 'overdue'>('all');
  const [selectedEmployee, setSelectedEmployee] = useState<string>('');

  const loadProjects = async () => {
    try {
      const projectsData = await api.getProjects();
      setProjects(projectsData);
    } catch (err) {
      console.error('Error loading projects:', err);
    }
  };

  const loadStatistics = async () => {
    try {
      setLoading(true);
      setError('');
      const data = await api.getStatistics();
      
      // Filter by project group if selected
      const filtered = selectedGroup
        ? data.filter((stat: ProjectStat) => {
            const project = projects.find(p => p.id === stat.id);
            return project?.project_groups?.some(g => g.name === selectedGroup);
          })
        : data;
      
      setStatistics(filtered);
    } catch (err) {
      setError('Hiba a statisztika betöltésekor');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const loadEmployeeStats = async () => {
    try {
      const data = await api.getEmployeeProjects();
      
      // Calculate total hours per employee
      const employeeData: EmployeeStat[] = data.map((emp: any) => {
        const totalHours = emp.projects.reduce((sum: number, p: any) => sum + (p.actual_hours || 0), 0);
        return {
          employee_id: emp.employee_id,
          employee_name: emp.employee_name,
          total_hours: totalHours,
          project_count: emp.projects.length,
          projects: emp.projects
        };
      });

      // Sort by total hours descending
      employeeData.sort((a, b) => b.total_hours - a.total_hours);
      
      setEmployeeStats(employeeData);
    } catch (err) {
      console.error('Error loading employee stats:', err);
    }
  };

  useEffect(() => {
    loadProjects();
    loadStatistics();
    loadEmployeeStats();
  }, []);

  useEffect(() => {
    loadStatistics();
  }, [selectedGroup, projects]);

  // Get unique project group names
  const projectGroupNames = Array.from(new Set(
    projects
      .flatMap(p => p.project_groups?.map(g => g.name) || [])
      .filter((name): name is string => !!name)
  ));

  // Filter and sort statistics
  const getFilteredAndSortedStats = () => {
    let filtered = [...statistics];

    // Apply status filter
    if (filterStatus !== 'all') {
      filtered = filtered.filter(stat => {
        if (filterStatus === 'completed') return stat.progress >= 1;
        if (filterStatus === 'inProgress') return stat.progress > 0 && stat.progress < 1;
        if (filterStatus === 'overdue') return stat.actual_hours > stat.target_hours;
        return true;
      });
    }

    // Apply sorting
    filtered.sort((a, b) => {
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      if (sortBy === 'progress') return b.progress - a.progress;
      if (sortBy === 'hours') return b.actual_hours - a.actual_hours;
      return 0;
    });

    return filtered;
  };

  const filteredStats = getFilteredAndSortedStats();

  // Prepare chart data
  const chartData = filteredStats.slice(0, 10).map(stat => ({
    name: stat.name.length > 20 ? stat.name.substring(0, 20) + '...' : stat.name,
    fullName: stat.name,
    planned: stat.target_hours,
    actual: stat.actual_hours,
    progress: (stat.progress * 100).toFixed(1)
  }));

  const pieData = filteredStats.slice(0, 8).map(stat => ({
    name: stat.name.length > 15 ? stat.name.substring(0, 15) + '...' : stat.name,
    value: stat.actual_hours,
    fullName: stat.name
  }));

  const COLORS = ['#6366f1', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#3b82f6', '#ef4444', '#14b8a6'];

  if (loading) {
    return (
      <Card className="p-6">
        <p className="text-gray-600">Betöltés...</p>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="p-6">
        <p className="text-red-600">{error}</p>
      </Card>
    );
  }

  if (statistics.length === 0 && !loading) {
    return (
      <Card className="p-6">
        <p className="text-gray-600">Még nincs statisztika.</p>
      </Card>
    );
  }

  // Calculate overall stats
  const totalTarget = statistics.reduce((sum, s) => sum + s.target_hours, 0);
  const totalActual = statistics.reduce((sum, s) => sum + s.actual_hours, 0);
  const overallProgress = totalTarget > 0 ? (totalActual / totalTarget) * 100 : 0;

  const exportProjectsToCSV = () => {
    const csvContent: string[] = [];
    csvContent.push('Projekt név,Tervezett óra,Ledolgozott óra,Előrehaladás (%),Hátralévő óra');

    statistics.forEach(project => {
      const percentage = (project.progress * 100).toFixed(0);
      const remaining = Math.max(0, project.remaining).toFixed(1);
      csvContent.push(`"${project.name}","${project.target_hours}","${project.actual_hours.toFixed(1)}","${percentage}","${remaining}"`);
    });

    // Add total row
    csvContent.push(`"Összesen","${totalTarget}","${totalActual.toFixed(1)}","${overallProgress.toFixed(0)}",""`);

    const csv = csvContent.join('\n');
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', `statisztika_projektek_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportEmployeesToCSV = () => {
    const csvContent: string[] = [];
    csvContent.push('Dolgozó név,Projektek száma,Összesen ledolgozott óra');

    employeeStats.forEach(employee => {
      csvContent.push(`"${employee.employee_name}","${employee.project_count}","${employee.total_hours.toFixed(1)}"`);
    });

    // Add total row
    const totalHours = employeeStats.reduce((sum, e) => sum + e.total_hours, 0);
    csvContent.push(`"Összesen","","${totalHours.toFixed(1)}"`);

    const csv = csvContent.join('\n');
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', `statisztika_dolgozok_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      <Card className="p-4 sm:p-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <h2 className="text-xl font-bold">Statisztika nézet</h2>
          <button
            onClick={viewMode === 'projects' ? exportProjectsToCSV : exportEmployeesToCSV}
            className="px-4 py-2 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition w-full sm:w-auto"
          >
            📥 Export CSV
          </button>
        </div>
        
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <button
              onClick={() => setViewMode('projects')}
              className={`px-4 py-2 rounded-md font-medium transition-colors ${
                viewMode === 'projects'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              📊 Projekt bontás
            </button>
            <button
              onClick={() => setViewMode('employees')}
              className={`px-4 py-2 rounded-md font-medium transition-colors ${
                viewMode === 'employees'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              👥 Dolgozó bontás
            </button>
          </div>

          {viewMode === 'projects' && (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                <select
                  value={selectedGroup}
                  onChange={(e) => setSelectedGroup(e.target.value)}
                  className="flex h-9 w-full items-center justify-between rounded-md border border-input bg-white px-3 py-2 text-sm shadow-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <option value="">🗂️ Összes projekt</option>
                  {projectGroupNames.map((groupName) => (
                    <option key={groupName} value={groupName}>
                      {groupName}
                    </option>
                  ))}
                </select>

                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value as any)}
                  className="flex h-9 w-full items-center justify-between rounded-md border border-input bg-white px-3 py-2 text-sm shadow-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="all">🔍 Minden állapot</option>
                  <option value="completed">✅ Befejezett</option>
                  <option value="inProgress">⏳ Folyamatban</option>
                  <option value="overdue">⚠️ Túllépett</option>
                </select>

                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="flex h-9 w-full items-center justify-between rounded-md border border-input bg-white px-3 py-2 text-sm shadow-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="progress">📈 Előrehaladás szerint</option>
                  <option value="name">🔤 Név szerint</option>
                  <option value="hours">⏱️ Órák szerint</option>
                </select>

                <select
                  value={chartType}
                  onChange={(e) => setChartType(e.target.value as any)}
                  className="flex h-9 w-full items-center justify-between rounded-md border border-input bg-white px-3 py-2 text-sm shadow-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="bar">📊 Fektetett oszlopdiagram</option>
                  <option value="pie">🥧 Kördiagram</option>
                  <option value="line">📈 Vonaldiagram</option>
                </select>
              </div>
            </>
          )}

          {viewMode === 'employees' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <select
                value={selectedEmployee}
                onChange={(e) => setSelectedEmployee(e.target.value)}
                className="flex h-9 w-full items-center justify-between rounded-md border border-input bg-white px-3 py-2 text-sm shadow-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-purple-500"
              >
                <option value="">👥 Összes dolgozó</option>
                {employeeStats.map((emp) => (
                  <option key={emp.employee_id} value={emp.employee_id.toString()}>
                    {emp.employee_name}
                  </option>
                ))}
              </select>
            </div>
          )}


        </div>
      </Card>

      {viewMode === 'projects' ? (
        <>
          <Card className="p-4 sm:p-6 bg-gradient-to-br from-indigo-50 to-blue-50 border-indigo-200">
            <h2 className="text-xl font-bold mb-6 text-gray-900">📈 Összesített statisztika</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
              <div className="bg-white rounded-lg p-4 shadow-sm">
                <p className="text-sm text-gray-600 mb-1">⏱️ Tervezett óra</p>
                <p className="text-3xl font-bold text-indigo-600">{totalTarget.toFixed(0)}</p>
              </div>
              <div className="bg-white rounded-lg p-4 shadow-sm">
                <p className="text-sm text-gray-600 mb-1">✅ Ledolgozott óra</p>
                <p className="text-3xl font-bold text-green-600">{totalActual.toFixed(1)}</p>
              </div>
              <div className="bg-white rounded-lg p-4 shadow-sm">
                <p className="text-sm text-gray-600 mb-1">📊 Előrehaladás</p>
                <p className="text-3xl font-bold text-gray-900">{overallProgress.toFixed(0)}%</p>
              </div>
            </div>
            <div>
              <p className="text-sm text-gray-600 mb-2">Teljes előrehaladás</p>
              <Progress value={Math.min(overallProgress, 100)} className="h-3" />
            </div>
          </Card>

          {filteredStats.length > 0 && (
            <Card className="p-4 sm:p-6 bg-gradient-to-br from-gray-50 to-indigo-50 border-indigo-100">
              <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
                <span className="text-2xl">📊</span>
                <span>Vizuális áttekintés</span>
              </h2>
              <div className="w-full overflow-x-auto">
                {chartType === 'bar' && (
                  <div className="bg-white rounded-lg p-6 shadow-sm">
                    <RechartsContainer width="100%" height={Math.max(500, chartData.length * 70)} minWidth={300}>
                      <RechartsBarChart 
                        data={chartData} 
                        layout="vertical"
                        margin={{ top: 20, right: 100, bottom: 20, left: 20 }}
                      >
                        <RechartsCartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" horizontal={true} vertical={true} />
                        <RechartsXAxis 
                          type="number" 
                          stroke="#6b7280"
                          tick={{ fontSize: 13, fill: '#374151' }}
                          tickLine={{ stroke: '#9ca3af' }}
                        />
                        <RechartsYAxis 
                          type="category" 
                          dataKey="name" 
                          width={150}
                          tick={{ fontSize: 13, fill: '#374151' }}
                          tickLine={{ stroke: '#9ca3af' }}
                          stroke="#6b7280"
                        />
                        <RechartsTooltip 
                          content={({ active, payload }) => {
                            if (active && payload && payload.length) {
                              return (
                                <div className="bg-white p-4 border-2 border-indigo-300 rounded-xl shadow-2xl">
                                  <p className="font-bold text-base mb-3 text-gray-900">{payload[0].payload.fullName}</p>
                                  <div className="space-y-2">
                                    <p className="text-indigo-600 text-sm font-medium">📋 Tervezett: {payload[0].value} óra</p>
                                    <p className="text-green-600 text-sm font-medium">✅ Ledolgozott: {payload[1].value} óra</p>
                                    <p className="text-gray-700 text-sm font-semibold border-t pt-2">📊 Előrehaladás: {payload[0].payload.progress}%</p>
                                  </div>
                                </div>
                              );
                            }
                            return null;
                          }}
                        />
                        <RechartsLegend 
                          wrapperStyle={{ paddingTop: '30px', fontSize: '14px' }}
                          iconType="rect"
                          iconSize={16}
                        />
                        <RechartsBar dataKey="planned" fill="#6366f1" name="Tervezett óra" radius={[0, 6, 6, 0]} barSize={25}>
                          <RechartsLabelList 
                            dataKey="planned" 
                            position="right" 
                            style={{ fill: '#4338ca', fontWeight: '600', fontSize: 13 }} 
                            formatter={(value: number) => `${value}h`}
                          />
                        </RechartsBar>
                        <RechartsBar dataKey="actual" fill="#10b981" name="Ledolgozott óra" radius={[0, 6, 6, 0]} barSize={25}>
                          <RechartsLabelList 
                            dataKey="actual" 
                            position="right" 
                            style={{ fill: '#047857', fontWeight: '600', fontSize: 13 }} 
                            formatter={(value: number) => `${value}h`}
                          />
                        </RechartsBar>
                      </RechartsBarChart>
                    </RechartsContainer>
                  </div>
                )}

                {chartType === 'pie' && (
                  <RechartsContainer width="100%" height={500} minWidth={300}>
                    <RechartsPieChart>
                      <RechartsPie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        labelLine={true}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={140}
                        innerRadius={60}
                        fill="#8884d8"
                        dataKey="value"
                        paddingAngle={3}
                      >
                        {pieData.map((entry, index) => (
                          <RechartsCell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </RechartsPie>
                      <RechartsTooltip 
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            return (
                              <div className="bg-white p-4 border-2 border-indigo-200 rounded-xl shadow-2xl">
                                <p className="font-bold text-base mb-2 text-gray-900">{payload[0].payload.fullName}</p>
                                <p className="text-green-600 text-sm font-medium">⏱️ Ledolgozott: {payload[0].value} óra</p>
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <RechartsLegend 
                        verticalAlign="bottom" 
                        height={36}
                        wrapperStyle={{ paddingTop: '20px' }}
                      />
                    </RechartsPieChart>
                  </RechartsContainer>
                )}

                {chartType === 'line' && (
                  <RechartsContainer width="100%" height={450} minWidth={300}>
                    <RechartsLineChart 
                      data={chartData}
                      margin={{ top: 20, right: 30, bottom: 100, left: 30 }}
                    >
                      <RechartsCartesianGrid strokeDasharray="3 3" stroke="#e0e7ff" />
                      <RechartsXAxis 
                        dataKey="name" 
                        angle={-45} 
                        textAnchor="end" 
                        height={100} 
                        fontSize={12}
                        stroke="#6366f1"
                      />
                      <RechartsYAxis stroke="#6366f1" />
                      <RechartsTooltip 
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            return (
                              <div className="bg-white p-4 border-2 border-indigo-200 rounded-xl shadow-2xl">
                                <p className="font-bold text-base mb-2 text-gray-900">{payload[0].payload.fullName}</p>
                                <div className="space-y-1">
                                  <p className="text-indigo-600 text-sm font-medium">📋 Tervezett: {payload[0].value} óra</p>
                                  <p className="text-green-600 text-sm font-medium">✅ Ledolgozott: {payload[1].value} óra</p>
                                </div>
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <RechartsLegend 
                        wrapperStyle={{ paddingTop: '20px' }}
                        iconType="line"
                      />
                      <RechartsLine 
                        type="monotone" 
                        dataKey="planned" 
                        stroke="#6366f1" 
                        strokeWidth={3} 
                        name="Tervezett óra"
                        dot={{ fill: '#6366f1', strokeWidth: 2, r: 5 }}
                        activeDot={{ r: 8 }}
                      />
                      <RechartsLine 
                        type="monotone" 
                        dataKey="actual" 
                        stroke="#10b981" 
                        strokeWidth={3} 
                        name="Ledolgozott óra"
                        dot={{ fill: '#10b981', strokeWidth: 2, r: 5 }}
                        activeDot={{ r: 8 }}
                      />
                    </RechartsLineChart>
                  </RechartsContainer>
                )}
              </div>
            </Card>
          )}

          <Card className="p-4 sm:p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold">📋 Projektek részletesen</h2>
              <p className="text-sm text-gray-600">{filteredStats.length} projekt</p>
            </div>
            <div className="space-y-4">
              {filteredStats.map((project) => {
                const percentage = Math.min(project.progress * 100, 100);
                const isCompleted = project.progress >= 1;
                const isOverdue = project.actual_hours > project.target_hours;

                return (
                  <div
                    key={project.id}
                    className={`border rounded-lg p-4 transition-all hover:shadow-md ${
                      isCompleted ? 'border-green-300 bg-green-50' : 
                      isOverdue ? 'border-red-300 bg-red-50' : 
                      'border-gray-200'
                    }`}
                  >
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold text-gray-900">{project.name}</h3>
                          {isCompleted && <span className="text-green-600 text-sm">✅</span>}
                          {isOverdue && !isCompleted && <span className="text-red-600 text-sm">⚠️</span>}
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-gray-900">
                          {project.actual_hours.toFixed(1)} / {project.target_hours} óra
                        </p>
                        <p className="text-sm text-gray-600">{percentage.toFixed(0)}%</p>
                      </div>
                    </div>

                    <Progress value={percentage} className="h-2 mb-3" />

                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-gray-600">Tervezett</p>
                        <p className="font-semibold text-gray-900">
                          {project.target_hours} óra
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-600">Hátralévő</p>
                        <p
                          className={`font-semibold ${
                            project.remaining > 0
                              ? 'text-orange-600'
                              : 'text-green-600'
                          }`}
                        >
                          {Math.max(0, project.remaining).toFixed(1)} óra
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </>
      ) : (
        <>
          {(() => {
            const filteredEmployees = selectedEmployee
              ? employeeStats.filter(e => e.employee_id.toString() === selectedEmployee)
              : employeeStats;

            return (
              <>
                <Card className="p-4 sm:p-6 bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
                  <h2 className="text-xl font-bold mb-6 text-gray-900">👥 Dolgozók összesített statisztikája</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div className="bg-white rounded-lg p-4 shadow-sm">
                      <p className="text-sm text-gray-600 mb-1">👤 Dolgozók száma</p>
                      <p className="text-3xl font-bold text-purple-600">{filteredEmployees.length}</p>
                    </div>
                    <div className="bg-white rounded-lg p-4 shadow-sm">
                      <p className="text-sm text-gray-600 mb-1">⏱️ Összes ledolgozott óra</p>
                      <p className="text-3xl font-bold text-green-600">
                        {filteredEmployees.reduce((sum, e) => sum + e.total_hours, 0).toFixed(1)}
                      </p>
                    </div>
                    <div className="bg-white rounded-lg p-4 shadow-sm">
                      <p className="text-sm text-gray-600 mb-1">📊 Átlag óra/dolgozó</p>
                      <p className="text-3xl font-bold text-gray-900">
                        {filteredEmployees.length > 0
                          ? (filteredEmployees.reduce((sum, e) => sum + e.total_hours, 0) / filteredEmployees.length).toFixed(1)
                          : '0'}
                      </p>
                    </div>
                  </div>
                </Card>

                {filteredEmployees.length > 0 && (() => {
                  const employeeChartData = filteredEmployees.slice(0, 15).map(emp => ({
                    name: emp.employee_name.length > 20 ? emp.employee_name.substring(0, 20) + '...' : emp.employee_name,
                    fullName: emp.employee_name,
                    hours: emp.total_hours,
                    projects: emp.project_count
                  }));

                  return (
                    <Card className="p-4 sm:p-6 bg-gradient-to-br from-gray-50 to-purple-50 border-purple-100">
                      <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
                        <span className="text-2xl">📊</span>
                        <span>Dolgozók vizuális áttekintés</span>
                      </h2>
                      <div className="w-full overflow-x-auto bg-white rounded-lg p-6 shadow-sm">
                        <RechartsContainer width="100%" height={Math.max(500, employeeChartData.length * 70)} minWidth={300}>
                          <RechartsBarChart 
                            data={employeeChartData}
                            layout="vertical"
                            margin={{ top: 20, right: 100, bottom: 20, left: 20 }}
                          >
                            <RechartsCartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" horizontal={true} vertical={true} />
                            <RechartsXAxis 
                              type="number" 
                              stroke="#6b7280"
                              tick={{ fontSize: 13, fill: '#374151' }}
                              tickLine={{ stroke: '#9ca3af' }}
                            />
                            <RechartsYAxis 
                              type="category" 
                              dataKey="name" 
                              width={150}
                              tick={{ fontSize: 13, fill: '#374151' }}
                              tickLine={{ stroke: '#9ca3af' }}
                              stroke="#6b7280"
                            />
                            <RechartsTooltip 
                              content={({ active, payload }) => {
                                if (active && payload && payload.length) {
                                  return (
                                    <div className="bg-white p-4 border-2 border-purple-300 rounded-xl shadow-2xl">
                                      <p className="font-bold text-base mb-3 text-gray-900">{payload[0].payload.fullName}</p>
                                      <div className="space-y-2">
                                        <p className="text-green-600 text-sm font-medium">⏱️ Ledolgozott: {payload[0].value} óra</p>
                                        <p className="text-purple-600 text-sm font-medium border-t pt-2">📁 Projektek: {payload[0].payload.projects}</p>
                                      </div>
                                    </div>
                                  );
                                }
                                return null;
                              }}
                            />
                            <RechartsLegend 
                              wrapperStyle={{ paddingTop: '30px', fontSize: '14px' }}
                              iconType="rect"
                              iconSize={16}
                            />
                            <RechartsBar dataKey="hours" fill="#8b5cf6" name="Ledolgozott órák" radius={[0, 6, 6, 0]} barSize={30}>
                              <RechartsLabelList 
                                dataKey="hours" 
                                position="right" 
                                style={{ fill: '#6d28d9', fontWeight: '600', fontSize: 13 }} 
                                formatter={(value: number) => `${value}h`}
                              />
                            </RechartsBar>
                          </RechartsBarChart>
                        </RechartsContainer>
                      </div>
                    </Card>
                  );
                })()}

                <Card className="p-4 sm:p-6">
                  <div className="flex justify-between items-center mb-6">
                    <h2 className="text-xl font-bold">📋 Dolgozók részletesen</h2>
                    <p className="text-sm text-gray-600">{filteredEmployees.length} dolgozó</p>
                  </div>
                  <div className="space-y-4">
                    {filteredEmployees.map((employee, index) => {
                      const maxHours = Math.max(...filteredEmployees.map(e => e.total_hours));
                      const percentage = maxHours > 0 ? (employee.total_hours / maxHours) * 100 : 0;
                      const isTopPerformer = index < 3 && !selectedEmployee;

                      return (
                        <div
                          key={employee.employee_id}
                          className={`border rounded-lg p-4 transition-all hover:shadow-md ${
                            isTopPerformer ? 'border-purple-300 bg-purple-50' : 'border-gray-200'
                          }`}
                        >
                          <div className="flex justify-between items-start mb-3">
                            <div className="flex items-center gap-2">
                              <h3 className="font-semibold text-gray-900">{employee.employee_name}</h3>
                              {isTopPerformer && <span className="text-yellow-500">🏆</span>}
                            </div>
                            <div className="text-right">
                              <p className="font-semibold text-gray-900">
                                {employee.total_hours.toFixed(1)} óra
                              </p>
                              <p className="text-sm text-gray-600">{employee.project_count} projekt</p>
                            </div>
                          </div>

                          <Progress value={percentage} className="h-2" />
                        </div>
                      );
                    })}
                  </div>
                </Card>
              </>
            );
          })()}
        </>
      )}
    </div>
  );
}
