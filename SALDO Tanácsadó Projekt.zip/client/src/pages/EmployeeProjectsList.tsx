import { useEffect, useState } from "react";
import { Card } from "../components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Progress } from "../components/ui/progress";
import { api } from "../lib/api";

interface EmployeeProject {
  id: number;
  name: string;
  target_hours: number;
  actual_hours: number;
  is_completed: number;
}

interface EmployeeProjectsData {
  employee_id: number;
  employee_name: string;
  projects: EmployeeProject[];
}

export function EmployeeProjectsList() {
  const [data, setData] = useState<EmployeeProjectsData[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "completed">("all");
  const [employeeFilter, setEmployeeFilter] = useState<string>("all");

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      setLoading(true);
      const result = await api.getEmployeeProjects();
      setData(result);
    } catch (err) {
      console.error("Failed to load employee projects:", err);
    } finally {
      setLoading(false);
    }
  }

  function handleStatusFilterChange(value: string) {
    setStatusFilter(value as "all" | "active" | "completed");
  }

  function handleEmployeeFilterChange(value: string) {
    setEmployeeFilter(value);
  }

  const filteredData = data
    .filter(emp => {
      if (employeeFilter === "all") return true;
      return emp.employee_id.toString() === employeeFilter;
    })
    .map(emp => ({
      ...emp,
      projects: emp.projects.filter(project => {
        if (statusFilter === "all") return true;
        if (statusFilter === "active") return project.is_completed === 0;
        if (statusFilter === "completed") return project.is_completed === 1;
        return true;
      })
    })).filter(emp => emp.projects.length > 0);

  if (loading) {
    return (
      <Card className="p-6">
        <p className="text-muted-foreground">Betöltés...</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4">
        <h2 className="text-2xl font-bold text-foreground">Dolgozók projektjei</h2>
        <div className="flex flex-col sm:flex-row gap-4">
          <Select value={employeeFilter} onValueChange={handleEmployeeFilterChange}>
            <SelectTrigger className="w-full sm:w-[200px]">
              <SelectValue placeholder="Összes dolgozó" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Összes dolgozó</SelectItem>
              {data.map(emp => (
                <SelectItem key={emp.employee_id} value={emp.employee_id.toString()}>
                  {emp.employee_name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={handleStatusFilterChange}>
            <SelectTrigger className="w-full sm:w-[200px]">
              <SelectValue placeholder="Válassz státuszt" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Összes projekt</SelectItem>
              <SelectItem value="active">Aktív projektek</SelectItem>
              <SelectItem value="completed">Lezárt projektek</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {filteredData.length === 0 ? (
        <Card className="p-8 text-center">
          <p className="text-muted-foreground">Nincs megjeleníthető adat.</p>
        </Card>
      ) : (
        <div className="grid gap-6">
          {filteredData.map(employee => {
            const totalTargetHours = employee.projects.reduce((sum, p) => sum + p.target_hours, 0);
            const totalActualHours = employee.projects.reduce((sum, p) => sum + p.actual_hours, 0);
            const overallProgress = totalTargetHours > 0 ? (totalActualHours / totalTargetHours) * 100 : 0;

            return (
              <Card key={employee.employee_id} className="p-6">
                <div className="mb-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
                    <h3 className="text-xl font-semibold text-foreground">
                      {employee.employee_name}
                    </h3>
                    <div className="flex gap-6 text-sm">
                      <div className="text-center">
                        <p className="text-muted-foreground">Tervezett</p>
                        <p className="text-lg font-bold text-foreground">{totalTargetHours}h</p>
                      </div>
                      <div className="text-center">
                        <p className="text-muted-foreground">Ledolgozott</p>
                        <p className="text-lg font-bold text-foreground">{totalActualHours}h</p>
                      </div>
                      <div className="text-center">
                        <p className="text-muted-foreground">Összesített</p>
                        <p className="text-lg font-bold text-foreground">{Math.round(overallProgress)}%</p>
                      </div>
                    </div>
                  </div>
                  <Progress value={Math.min(overallProgress, 100)} className="h-2" />
                </div>

                <div className="grid gap-3">
                  {employee.projects.map(project => {
                    const progress = project.target_hours > 0 
                      ? (project.actual_hours / project.target_hours) * 100 
                      : 0;
                    const isOvertime = project.actual_hours > project.target_hours;

                    return (
                      <div 
                        key={project.id} 
                        className="border rounded-lg p-4 hover:bg-muted/30 transition-colors"
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
                          <div className="flex-1">
                            <h4 className="font-medium text-foreground mb-1">{project.name}</h4>
                            <div className="flex items-center gap-2">
                              <span className={`inline-block px-2 py-1 rounded text-xs font-medium ${
                                project.is_completed === 1
                                  ? "bg-slate-100 text-slate-700"
                                  : "bg-emerald-100 text-emerald-700"
                              }`}>
                                {project.is_completed === 1 ? "Lezárt" : "Aktív"}
                              </span>
                              {isOvertime && (
                                <span className="inline-block px-2 py-1 rounded text-xs font-medium bg-amber-100 text-amber-700">
                                  Túlóra
                                </span>
                              )}
                            </div>
                          </div>
                          <div className="flex gap-4 text-sm">
                            <div>
                              <span className="text-muted-foreground">Tervezett: </span>
                              <span className="font-semibold text-foreground">{project.target_hours}h</span>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Ledolgozott: </span>
                              <span className={`font-semibold ${
                                isOvertime ? "text-amber-600" : "text-foreground"
                              }`}>
                                {project.actual_hours}h
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="space-y-1">
                          <div className="flex justify-between text-xs text-muted-foreground">
                            <span>{Math.round(progress)}%</span>
                            {isOvertime && (
                              <span className="text-amber-600">
                                +{project.actual_hours - project.target_hours}h túlóra
                              </span>
                            )}
                          </div>
                          <Progress 
                            value={Math.min(progress, 100)} 
                            className={`h-2 ${isOvertime ? "[&>div]:bg-amber-500" : ""}`}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
