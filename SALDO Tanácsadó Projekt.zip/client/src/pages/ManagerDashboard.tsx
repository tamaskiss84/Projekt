import { useState, useEffect } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card } from '../components/ui/card';

import { api, type Project, type User } from '../lib/api';
import { ProjectsList } from './ProjectsList';
import { EmployeesList } from './EmployeesList';
import { EmployeeProjectsList } from './EmployeeProjectsList';
import { StatisticsTab } from './StatisticsTab';
import { ProjectGroupsTab } from './ProjectGroupsTab';
import { ProjectImport } from '../components/ProjectImport';
import { EmployeeWorkHoursTab } from './EmployeeWorkHoursTab';

interface ProjectGroup {
  id: number;
  name: string;
}

export function ManagerDashboard() {
  const [activeTab, setActiveTab] = useState<'projects' | 'activeProjects' | 'completedProjects' | 'employeeProjects' | 'employeeWorkHours' | 'projectGroups' | 'statistics' | 'employees'>('projects');
  const [employees, setEmployees] = useState<User[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [projectGroups, setProjectGroups] = useState<ProjectGroup[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // New project form
  const [projectId, setProjectId] = useState('');
  const [projectName, setProjectName] = useState('');
  const [targetHours, setTargetHours] = useState('');
  const [assignedTo, setAssignedTo] = useState('');
  const [selectedProjectGroupIds, setSelectedProjectGroupIds] = useState<number[]>([]);
  const [noTargetHours, setNoTargetHours] = useState(false);

  // Edit mode
  const [editingProject, setEditingProject] = useState<Project | null>(null);

  // New employee form
  const [newEmail, setNewEmail] = useState('');
  const [newName, setNewName] = useState('');
  const [monthlyPlannedHours, setMonthlyPlannedHours] = useState('');

  // Edit employee
  const [editingEmployee, setEditingEmployee] = useState<User | null>(null);

  // Filters
  const [activeProjectsFilter, setActiveProjectsFilter] = useState<number | null>(null);
  const [completedProjectsFilter, setCompletedProjectsFilter] = useState<number | null>(null);
  const [completedStartDate, setCompletedStartDate] = useState('');
  const [completedEndDate, setCompletedEndDate] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      setError('');
      const [empRes, projRes, projectGroupsRes] = await Promise.all([
        api.getEmployees(),
        api.getProjects(),
        api.getProjectGroups()
      ]);
      setEmployees(empRes);
      setProjects(projRes);
      setProjectGroups(projectGroupsRes);
    } catch (err) {
      setError('Hiba az adatok betöltésekor');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!projectId || !projectName || (!targetHours && !noTargetHours) || selectedProjectGroupIds.length === 0) {
      setError('Tölts ki a kötelező mezőket!');
      return;
    }

    try {
      setLoading(true);
      setError('');
      await api.createProject(
        projectName, 
        projectId,
        noTargetHours ? null : Number(targetHours), 
        null,
        selectedProjectGroupIds
      );
      setProjectId('');
      setProjectName('');
      setTargetHours('');
      setAssignedTo('');
      setSelectedProjectGroupIds([]);
      setNoTargetHours(false);
      await loadData();
    } catch (err) {
      setError('Hiba a projekt létrehozásakor');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmail) {
      setError('Add meg az e-mail címet!');
      return;
    }

    try {
      setLoading(true);
      setError('');
      await api.createEmployee(newEmail, newName);
      setNewEmail('');
      setNewName('');
      await loadData();
    } catch (err) {
      setError('Hiba a dolgozó hozzáadásakor');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleEditEmployee = (employee: User) => {
    setEditingEmployee(employee);
    setNewEmail(employee.email);
    setNewName(employee.name || '');
    setMonthlyPlannedHours(employee.monthly_planned_hours ? employee.monthly_planned_hours.toString() : '168');
  };

  const handleUpdateEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingEmployee || !newEmail) {
      setError('Add meg az e-mail címet!');
      return;
    }

    try {
      setLoading(true);
      setError('');
      await api.updateEmployee(
        editingEmployee.id, 
        newEmail, 
        newName,
        monthlyPlannedHours ? Number(monthlyPlannedHours) : 168
      );
      setNewEmail('');
      setNewName('');
      setMonthlyPlannedHours('');
      setEditingEmployee(null);
      await loadData();
    } catch (err) {
      setError('Hiba a dolgozó módosításakor');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCancelEmployeeEdit = () => {
    setEditingEmployee(null);
    setNewEmail('');
    setNewName('');
    setMonthlyPlannedHours('');
  };

  const handleDeleteEmployee = async (employeeId: number) => {
    if (!window.confirm('Biztosan törlöd ezt a dolgozót? Ez minden kapcsolódó munkaóra naplót is törölni fog!')) {
      return;
    }

    try {
      setLoading(true);
      setError('');
      await api.deleteEmployee(employeeId);
      await loadData();
    } catch (err) {
      setError('Hiba a dolgozó törlésekor');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (employeeId: number) => {
    if (!window.confirm('Biztosan alaphelyzetbe állítod a jelszót?')) return;

    try {
      setError('');
      await api.resetEmployeePassword(employeeId);
      await loadData();
    } catch (err) {
      setError('Hiba a jelszó alaphelyzetbe állításakor');
      console.error(err);
    }
  };

  const handleToggleAdmin = async (employeeId: number, isAdmin: boolean) => {
    try {
      setError('');
      const employee = employees.find(e => e.id === employeeId);
      if (!employee) return;
      
      await api.updateEmployee(
        employeeId,
        employee.email,
        employee.name,
        employee.monthly_planned_hours,
        isAdmin
      );
      await loadData();
    } catch (err) {
      setError('Hiba az admin jog módosításakor');
      console.error(err);
    }
  };

  const handleEditProject = (project: Project) => {
    setEditingProject(project);
    setProjectName(project.name);
    setTargetHours(project.target_hours ? project.target_hours.toString() : '');
    setNoTargetHours(project.target_hours === null);
    setAssignedTo(project.assigned_to ? project.assigned_to.toString() : '');
    setSelectedProjectGroupIds(project.project_groups?.map(g => g.id) || []);
  };

  const handleUpdateProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProject || !projectName || (!targetHours && !noTargetHours) || selectedProjectGroupIds.length === 0) {
      setError('Tölts ki a kötelező mezőket!');
      return;
    }

    try {
      setLoading(true);
      setError('');
      await api.updateProject(
        editingProject.id, 
        projectName, 
        noTargetHours ? null : Number(targetHours), 
        null,
        selectedProjectGroupIds
      );
      setProjectName('');
      setTargetHours('');
      setAssignedTo('');
      setSelectedProjectGroupIds([]);
      setNoTargetHours(false);
      setEditingProject(null);
      await loadData();
    } catch (err) {
      setError('Hiba a projekt módosításakor');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCancelEdit = () => {
    setEditingProject(null);
    setProjectName('');
    setTargetHours('');
    setAssignedTo('');
    setSelectedProjectGroupIds([]);
    setNoTargetHours(false);
  };

  const handleToggleProjectGroup = (groupId: number) => {
    setSelectedProjectGroupIds(prev =>
      prev.includes(groupId)
        ? prev.filter(id => id !== groupId)
        : [...prev, groupId]
    );
  };

  const handleDeleteProject = async (project: Project) => {
    if (!window.confirm(`Biztosan törlöd a következő projektet: ${project.name}? Ez minden kapcsolódó munkaóra naplót is törölni fog!`)) {
      return;
    }

    try {
      setLoading(true);
      setError('');
      await api.deleteProject(project.id);
      await loadData();
    } catch (err) {
      setError('Hiba a projekt törlésekor');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCloseProject = async (project: Project) => {
    if (!window.confirm(`Biztosan lezárod a következő projektet: ${project.name}?`)) {
      return;
    }

    try {
      setLoading(true);
      setError('');
      await api.closeProject(project.id);
      await loadData();
    } catch (err) {
      setError('Hiba a projekt lezárásakor');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleReopenProject = async (project: Project) => {
    if (!window.confirm(`Biztosan újra megnyitod a következő projektet: ${project.name}?`)) {
      return;
    }

    try {
      setLoading(true);
      setError('');
      await api.reopenProject(project.id);
      await loadData();
    } catch (err) {
      setError('Hiba a projekt újranyitásakor');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const activeProjects = projects.filter(p => {
    if (p.is_completed) return false;
    if (activeProjectsFilter === null) return true;
    return p.project_groups?.some(g => g.id === activeProjectsFilter);
  });

  const completedProjects = projects.filter(p => {
    if (!p.is_completed) return false;
    if (completedProjectsFilter !== null && !p.project_groups?.some(g => g.id === completedProjectsFilter)) {
      return false;
    }
    
    if (completedStartDate && p.completed_at) {
      const completedDate = p.completed_at.split('T')[0];
      if (completedDate < completedStartDate) return false;
    }
    if (completedEndDate && p.completed_at) {
      const completedDate = p.completed_at.split('T')[0];
      if (completedDate > completedEndDate) return false;
    }
    
    return true;
  });

  const tabs = [
    { id: 'projects', label: 'Projektek kezelése', icon: '📋' },
    { id: 'activeProjects', label: 'Aktív projektek', icon: '🚀' },
    { id: 'completedProjects', label: 'Befejezett projektek', icon: '✅' },
    { id: 'employeeProjects', label: 'Dolgozók projektjei', icon: '👥' },
    { id: 'employeeWorkHours', label: 'Dolgozók munkaideje', icon: '⏱️' },
    { id: 'projectGroups', label: 'Projekt csoportok', icon: '📁' },
    { id: 'statistics', label: 'Statisztika', icon: '📊' },
    { id: 'employees', label: 'Dolgozók beállítása', icon: '⚙️' },
  ] as const;

  return (
    <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-8 py-4 sm:py-8">
      <div className="hidden lg:flex gap-3 mb-8 flex-wrap">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`group relative px-5 py-3 font-medium rounded-xl transition-all duration-200 ${
              activeTab === tab.id
                ? 'bg-gradient-to-r from-sky-500 to-blue-500 text-white shadow-lg shadow-sky-500/30 scale-105'
                : 'bg-white text-gray-700 hover:bg-gray-50 border-2 border-gray-200 hover:border-sky-300 hover:shadow-md'
            }`}
          >
            <span className="flex items-center gap-2">
              <span className={`text-lg ${activeTab === tab.id ? 'scale-110' : 'group-hover:scale-110'} transition-transform`}>
                {tab.icon}
              </span>
              <span className="text-sm whitespace-nowrap">{tab.label}</span>
            </span>
            {activeTab === tab.id && (
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-white rounded-full opacity-30"></div>
            )}
          </button>
        ))}
      </div>

      <div className="lg:hidden mb-6">
        <div className="flex gap-2 overflow-x-auto pb-3 scrollbar-hide snap-x snap-mandatory px-1">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`snap-center flex-shrink-0 px-4 py-3 rounded-xl font-medium transition-all duration-200 ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-sky-500 to-blue-500 text-white shadow-lg min-w-[140px]'
                  : 'bg-white text-gray-700 border-2 border-gray-200 min-w-[140px] hover:border-sky-300'
              }`}
            >
              <div className="flex flex-col items-center gap-1">
                <span className="text-xl">{tab.icon}</span>
                <span className="text-xs leading-tight text-center">{tab.label}</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
          {error}
        </div>
      )}

      {activeTab === 'projects' && (
        <div className="space-y-6">
          <ProjectImport 
            projectGroups={projectGroups}
            onImportComplete={loadData}
          />
          
          <Card className="p-6">
            <h2 className="text-xl font-bold mb-6">
              {editingProject ? 'Projekt szerkesztése' : 'Új projekt létrehozása'}
            </h2>
            <form onSubmit={editingProject ? handleUpdateProject : handleCreateProject} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Projekt azonosítója
                </label>
                <Input
                   type="text"
                   value={projectId}
                   onChange={(e) => setProjectId(e.target.value)}
                   placeholder="Munkaszám_sorszám"
                   disabled={loading || editingProject !== null}
                 />
                <p className="text-xs text-gray-500 mt-1">
                  Egyedi azonosító (nem módosítható szerkesztéskor)
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Projekt neve
                </label>
                <Input
                  type="text"
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                  placeholder="Projekt neve"
                  disabled={loading}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Tervezett óraszám
                </label>
                <div className="flex items-center gap-4 mb-2">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={noTargetHours}
                      onChange={(e) => {
                        setNoTargetHours(e.target.checked);
                        if (e.target.checked) {
                          setTargetHours('');
                        }
                      }}
                      disabled={loading}
                      className="w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
                    />
                    <span className="text-sm text-gray-700">Nincs óraszám</span>
                  </label>
                </div>
                <Input
                  type="number"
                  value={targetHours}
                  onChange={(e) => setTargetHours(e.target.value)}
                  placeholder="pl. 160"
                  min="1"
                  step="0.5"
                  disabled={loading || noTargetHours}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Projekt csoportok
                </label>
                <div className="max-h-64 overflow-y-auto border rounded-lg p-3 space-y-2">
                  {projectGroups.length === 0 ? (
                    <p className="text-sm text-gray-500">Nincs elérhető projekt csoport</p>
                  ) : (
                    projectGroups.map((group) => (
                      <label key={group.id} className="flex items-center space-x-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={selectedProjectGroupIds.includes(group.id)}
                          onChange={() => handleToggleProjectGroup(group.id)}
                          className="rounded"
                          disabled={loading}
                        />
                        <span className="text-sm">{group.name}</span>
                      </label>
                    ))
                  )}
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  type="submit"
                  className="bg-gradient-to-r from-sky-500 to-blue-500 hover:from-sky-600 hover:to-blue-600 flex-1 shadow-md"
                  disabled={loading}
                >
                  {loading ? 'Betöltés...' : editingProject ? 'Módosítás mentése' : 'Projekt mentése'}
                </Button>
                {editingProject && (
                  <Button
                    type="button"
                    onClick={handleCancelEdit}
                    variant="outline"
                    disabled={loading}
                  >
                    Mégse
                  </Button>
                )}
              </div>
            </form>
          </Card>
        </div>
      )}

      {activeTab === 'activeProjects' && (
        <Card className="p-6">
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Szűrés projektcsoport szerint
            </label>
            <select
              value={activeProjectsFilter === null ? '' : activeProjectsFilter}
              onChange={(e) => setActiveProjectsFilter(e.target.value === '' ? null : Number(e.target.value))}
              className="w-full md:w-64 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="">Mind</option>
              {projectGroups.map(group => (
                <option key={group.id} value={group.id}>{group.name}</option>
              ))}
            </select>
          </div>
          <ProjectsList 
            projects={activeProjects} 
            loading={loading} 
            isAdmin={true}
            onEdit={handleEditProject}
            onDelete={handleDeleteProject}
            onClose={handleCloseProject}
          />
        </Card>
      )}

      {activeTab === 'employees' && (
        <div className="space-y-8">
          <Card className="p-6">
            <h2 className="text-xl font-bold mb-6">
              {editingEmployee ? 'Dolgozó szerkesztése' : 'Új dolgozó hozzáadása'}
            </h2>
            <form onSubmit={editingEmployee ? handleUpdateEmployee : handleCreateEmployee} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Név (opcionális)
                </label>
                <Input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="Dolgozó neve"
                  disabled={loading}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  E-mail cím
                </label>
                <Input
                  type="email"
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  placeholder="dolgozó@ceg.hu"
                  disabled={loading}
                />
              </div>

              {editingEmployee && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Havi tervezett munkaidő (óra)
                  </label>
                  <Input
                    type="number"
                    value={monthlyPlannedHours}
                    onChange={(e) => setMonthlyPlannedHours(e.target.value)}
                    placeholder="168"
                    min="1"
                    step="0.5"
                    disabled={loading}
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Alapértelmezett: 168 óra/hó (teljes munkaidő)
                  </p>
                </div>
              )}

              <div className="flex gap-2">
                <Button
                  type="submit"
                  className="bg-gradient-to-r from-sky-500 to-blue-500 hover:from-sky-600 hover:to-blue-600 flex-1 shadow-md"
                  disabled={loading}
                >
                  {loading ? 'Betöltés...' : editingEmployee ? 'Módosítás mentése' : 'Hozzáadás'}
                </Button>
                {editingEmployee && (
                  <Button
                    type="button"
                    onClick={handleCancelEmployeeEdit}
                    variant="outline"
                    disabled={loading}
                  >
                    Mégse
                  </Button>
                )}
              </div>

              {!editingEmployee && (
                <p className="text-sm text-gray-600">
                  Ideiglenes jelszó: <strong>1234</strong>
                </p>
              )}
            </form>
          </Card>

          <EmployeesList
            employees={employees}
            loading={loading}
            onResetPassword={handleResetPassword}
            onEdit={handleEditEmployee}
            onDelete={handleDeleteEmployee}
            onToggleAdmin={handleToggleAdmin}
          />
        </div>
      )}

      {activeTab === 'employeeProjects' && <EmployeeProjectsList />}

      {activeTab === 'completedProjects' && (
        <Card className="p-6">
          <h2 className="text-xl font-bold mb-6 text-gray-900">Befejezett projektek</h2>
          
          <div className="mb-6 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Szűrés projektcsoport szerint
              </label>
              <select
                value={completedProjectsFilter === null ? '' : completedProjectsFilter}
                onChange={(e) => setCompletedProjectsFilter(e.target.value === '' ? null : Number(e.target.value))}
                className="w-full md:w-64 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">Mind</option>
                {projectGroups.map(group => (
                  <option key={group.id} value={group.id}>{group.name}</option>
                ))}
              </select>
            </div>
            
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Lezárás kezdő dátuma
                </label>
                <Input
                  type="date"
                  value={completedStartDate}
                  onChange={(e) => setCompletedStartDate(e.target.value)}
                />
              </div>
              <div className="flex-1">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Lezárás vég dátuma
                </label>
                <Input
                  type="date"
                  value={completedEndDate}
                  onChange={(e) => setCompletedEndDate(e.target.value)}
                />
              </div>
            </div>
          </div>
          
          {completedProjects.length === 0 ? (
            <p className="text-gray-600">Még nincs befejezett projekt.</p>
          ) : (
            <div className="space-y-6">
              {completedProjects.map((project) => (
                <div
                  key={project.id}
                  className="border border-gray-200 rounded-lg p-4 bg-gray-50"
                >
                  <div className="flex flex-col sm:flex-row justify-between items-start gap-3 mb-2">
                    <div className="flex-1">
                      <p className="text-sm text-gray-500">Projekt neve</p>
                      <p className="font-medium">{project.name}</p>
                      <p className="text-xs text-gray-400 mt-1">
                        Csoportok: {project.project_groups && project.project_groups.length > 0
                          ? project.project_groups.map(g => g.name).join(', ')
                          : '-'}
                      </p>
                      {project.completed_at && (
                        <p className="text-xs text-gray-400 mt-1">
                          Lezárva: {new Date(project.completed_at).toLocaleDateString('hu-HU')}
                        </p>
                      )}
                    </div>
                    <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
                      <div className="text-right mb-2 sm:mb-0 sm:mr-4">
                        <p className="font-semibold text-gray-900">
                          {project.actual_hours?.toFixed(1) || 0} {project.target_hours !== null ? `/ ${project.target_hours} óra` : 'óra'}
                        </p>
                        {project.target_hours !== null && (
                          <p className="text-sm text-gray-700">
                            {Math.min((project.actual_hours || 0) / project.target_hours * 100, 100).toFixed(0)}%
                          </p>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleEditProject(project)}
                          className="px-3 py-1 text-xs sm:text-sm bg-blue-600 text-white rounded hover:bg-blue-700 transition flex-1 sm:flex-initial whitespace-nowrap"
                          disabled={loading}
                        >
                          Szerkesztés
                        </button>
                        <button
                          onClick={() => handleReopenProject(project)}
                          className="px-3 py-1 text-xs sm:text-sm bg-green-600 text-white rounded hover:bg-green-700 transition flex-1 sm:flex-initial whitespace-nowrap"
                          disabled={loading}
                        >
                          Felnyitás
                        </button>
                        <button
                          onClick={() => handleDeleteProject(project)}
                          className="px-3 py-1 text-xs sm:text-sm bg-red-600 text-white rounded hover:bg-red-700 transition flex-1 sm:flex-initial whitespace-nowrap"
                          disabled={loading}
                        >
                          Törlés
                        </button>
                      </div>
                    </div>
                  </div>
                  
                  {project.employee_logs && project.employee_logs.length > 0 && (
                    <div className="mt-4 pt-4 border-t border-gray-200">
                      <p className="text-sm font-semibold text-gray-700 mb-2">Dolgozók órái:</p>
                      <div className="space-y-1">
                        {project.employee_logs.map((log) => (
                          <div key={log.user_id} className="flex justify-between text-sm">
                            <span className="text-gray-600">{log.user_name}</span>
                            <span className="font-medium text-gray-900">{log.total_hours.toFixed(1)} óra</span>
                          </div>
                        ))}
                        <div className="flex justify-between text-sm font-semibold pt-2 border-t border-gray-100">
                          <span className="text-gray-700">Összesen:</span>
                          <span className="text-gray-900">{project.actual_hours?.toFixed(1) || 0} óra</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </Card>
      )}

      {activeTab === 'projectGroups' && <ProjectGroupsTab />}

      {activeTab === 'statistics' && <StatisticsTab />}

      {activeTab === 'employeeWorkHours' && <EmployeeWorkHoursTab />}
    </div>
  );
}
