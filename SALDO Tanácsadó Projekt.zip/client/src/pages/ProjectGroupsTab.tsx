import { useState, useEffect } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card } from '../components/ui/card';
import { api } from '../lib/api';
import { ProjectGroupImport } from '../components/ProjectGroupImport';

interface ProjectGroup {
  id: number;
  name: string;
  member_ids: number[];
}

interface Employee {
  id: number;
  email: string;
  name: string;
}

export function ProjectGroupsTab() {
  const [groups, setGroups] = useState<ProjectGroup[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [groupName, setGroupName] = useState('');
  const [selectedEmployees, setSelectedEmployees] = useState<number[]>([]);
  const [editingGroup, setEditingGroup] = useState<ProjectGroup | null>(null);

  useEffect(() => {
    loadGroups();
    loadEmployees();
  }, []);

  const loadEmployees = async () => {
    try {
      const data = await api.getEmployees();
      setEmployees(data);
    } catch (err) {
      console.error('Failed to load employees:', err);
    }
  };

  const loadGroups = async () => {
    try {
      setLoading(true);
      setError('');
      const data = await api.getProjectGroups();
      setGroups(data);
    } catch (err) {
      setError('Hiba a projekt csoportok betöltésekor');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!groupName) {
      setError('Add meg a csoport nevét!');
      return;
    }

    try {
      setLoading(true);
      setError('');
      await api.createProjectGroup(groupName, selectedEmployees);
      setGroupName('');
      setSelectedEmployees([]);
      await loadGroups();
    } catch (err) {
      setError('Hiba a csoport létrehozásakor');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleEditGroup = (group: ProjectGroup) => {
    setEditingGroup(group);
    setGroupName(group.name);
    setSelectedEmployees(group.member_ids || []);
  };

  const handleUpdateGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingGroup || !groupName) {
      setError('Add meg a csoport nevét!');
      return;
    }

    try {
      setLoading(true);
      setError('');
      await api.updateProjectGroup(editingGroup.id, groupName, selectedEmployees);
      setGroupName('');
      setSelectedEmployees([]);
      setEditingGroup(null);
      await loadGroups();
    } catch (err) {
      setError('Hiba a csoport módosításakor');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCancelEdit = () => {
    setEditingGroup(null);
    setGroupName('');
    setSelectedEmployees([]);
  };

  const handleToggleEmployee = (employeeId: number) => {
    setSelectedEmployees(prev =>
      prev.includes(employeeId)
        ? prev.filter(id => id !== employeeId)
        : [...prev, employeeId]
    );
  };

  const handleDeleteGroup = async (group: ProjectGroup) => {
    if (!window.confirm(`Biztosan törlöd ezt a projekt csoportot: ${group.name}?`)) {
      return;
    }

    try {
      setLoading(true);
      setError('');
      await api.deleteProjectGroup(group.id);
      await loadGroups();
    } catch (err) {
      setError('Hiba a csoport törlésekor');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4 sm:space-y-8">
      <ProjectGroupImport employees={employees} onImportComplete={loadGroups} />
      
      <Card className="p-4 sm:p-6">
        <h2 className="text-lg sm:text-xl font-bold mb-4 sm:mb-6">
          {editingGroup ? 'Projekt csoport szerkesztése' : 'Új projekt csoport létrehozása'}
        </h2>
        <form onSubmit={editingGroup ? handleUpdateGroup : handleCreateGroup} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Csoport neve
            </label>
            <Input
              type="text"
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
              placeholder="pl. Webfejlesztés, Mobilalkalmazás"
              disabled={loading}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Csoporttagok (dolgozók)
            </label>
            <div className="max-h-48 sm:max-h-64 overflow-y-auto border rounded-lg p-2 sm:p-3 space-y-2">
              {employees.length === 0 ? (
                <p className="text-sm text-gray-500">Nincs elérhető dolgozó</p>
              ) : (
                employees.map((employee) => (
                  <label key={employee.id} className="flex items-center space-x-2 cursor-pointer p-1 hover:bg-gray-50 rounded">
                    <input
                      type="checkbox"
                      checked={selectedEmployees.includes(employee.id)}
                      onChange={() => handleToggleEmployee(employee.id)}
                      className="rounded w-4 h-4"
                      disabled={loading}
                    />
                    <span className="text-sm flex-1">{employee.name || employee.email}</span>
                  </label>
                ))
              )}
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-2">
            <Button
              type="submit"
              className="bg-indigo-600 hover:bg-indigo-700 flex-1 w-full sm:w-auto"
              disabled={loading}
            >
              {loading ? 'Betöltés...' : editingGroup ? 'Módosítás mentése' : 'Csoport létrehozása'}
            </Button>
            {editingGroup && (
              <Button
                type="button"
                onClick={handleCancelEdit}
                className="bg-gray-600 hover:bg-gray-700 w-full sm:w-auto"
                disabled={loading}
              >
                Mégse
              </Button>
            )}
          </div>
        </form>

        {error && (
          <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
            {error}
          </div>
        )}
      </Card>

      <Card className="p-4 sm:p-6">
        <h2 className="text-lg sm:text-xl font-bold mb-4 sm:mb-6">Projekt csoportok</h2>
        
        {loading && <p className="text-gray-600 text-sm">Betöltés...</p>}
        
        {!loading && groups.length === 0 && (
          <p className="text-gray-600 text-sm">Még nincs projekt csoport.</p>
        )}
        
        {!loading && groups.length > 0 && (
          <div className="space-y-3">
            {groups.map((group) => (
              <div
                key={group.id}
                className="flex flex-col sm:flex-row sm:items-center sm:justify-between p-3 sm:p-4 bg-gray-50 rounded-lg gap-3"
              >
                <div className="flex-1">
                  <p className="font-medium text-sm sm:text-base">{group.name}</p>
                  <p className="text-xs sm:text-sm text-gray-600 mt-1">
                    {group.member_ids?.length || 0} tag
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={() => handleEditGroup(group)}
                    className="bg-blue-600 hover:bg-blue-700 flex-1 sm:flex-none text-sm px-3 py-2"
                    disabled={loading}
                  >
                    Szerkesztés
                  </Button>
                  <Button
                    onClick={() => handleDeleteGroup(group)}
                    className="bg-red-600 hover:bg-red-700 flex-1 sm:flex-none text-sm px-3 py-2"
                    disabled={loading}
                  >
                    Törlés
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
