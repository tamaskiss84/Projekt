import { useState, useEffect } from 'react';
import { Card } from '../components/ui/card';
import { api } from '../lib/api';

import type { LogType } from '../lib/api';

interface LogWithComments {
  id: number;
  date: string;
  hours: number;
  project_id: number | null;
  project_name: string | null;
  log_type: LogType;
  comments: string | null;
}

interface DailyLog {
  date: string;
  total_hours: number;
  available_hours: number;
}

export function MonthlySummaryTab() {
  const [currentMonth, setCurrentMonth] = useState('');
  const [logs, setLogs] = useState<DailyLog[]>([]);
  const [totalAvailableHours, setTotalAvailableHours] = useState(0);
  const [loading, setLoading] = useState(false);
  const [detailedLogs, setDetailedLogs] = useState<LogWithComments[]>([]);

  useEffect(() => {
    // Set current month in YYYY-MM format
    const now = new Date();
    const monthString = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    setCurrentMonth(monthString);
  }, []);

  useEffect(() => {
    if (currentMonth) {
      loadMonthlyLogs();
    }
  }, [currentMonth]);

  const loadMonthlyLogs = async () => {
    try {
      setLoading(true);
      const data = await api.getMonthlySummary(currentMonth);
      setLogs(data.logs || []);
      setTotalAvailableHours(data.total_available_hours || 0);
      
      // Load detailed logs with comments for the month
      const [year, month] = currentMonth.split('-');
      const startDate = `${year}-${month}-01`;
      const lastDay = new Date(Number(year), Number(month), 0).getDate();
      const endDate = `${year}-${month}-${String(lastDay).padStart(2, '0')}`;
      const allLogs = await api.getAllLogs(startDate, endDate);
      setDetailedLogs(allLogs || []);
    } catch (err) {
      console.error('Error loading monthly logs:', err);
      setLogs([]);
      setTotalAvailableHours(0);
      setDetailedLogs([]);
    } finally {
      setLoading(false);
    }
  };

  const getTotalHours = () => {
    return getAllDaysInMonth().reduce((sum, log) => sum + log.total_hours, 0);
  };

  const getDayName = (dateString: string) => {
    const date = new Date(dateString + 'T00:00:00');
    const days = ['Vasárnap', 'Hétfő', 'Kedd', 'Szerda', 'Csütörtök', 'Péntek', 'Szombat'];
    return days[date.getDay()];
  };

  const isWeekend = (dateString: string) => {
    const date = new Date(dateString + 'T00:00:00');
    const day = date.getDay();
    return day === 0 || day === 6;
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  };

  const getAllDaysInMonth = () => {
    if (!currentMonth) return [];
    
    const [year, month] = currentMonth.split('-').map(Number);
    const daysInMonth = new Date(year, month, 0).getDate();
    const allDays = [];
    
    for (let day = 1; day <= daysInMonth; day++) {
      const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const existingLog = logs.find(log => formatDate(log.date) === dateStr);
      
      const date = new Date(year, month - 1, day);
      const dayOfWeek = date.getDay();
      let availableHours = 0;
      
      // Monday-Thursday: 8.5 hours, Friday: 6 hours
      if (dayOfWeek >= 1 && dayOfWeek <= 4) {
        availableHours = 8.5;
      } else if (dayOfWeek === 5) {
        availableHours = 6;
      }
      
      allDays.push({
        date: dateStr,
        total_hours: existingLog ? existingLog.total_hours : 0,
        available_hours: availableHours
      });
    }
    
    return allDays;
  };

  return (
    <div className="max-w-6xl mx-auto px-2 sm:px-4 py-4 sm:py-6">
      <Card className="p-3 sm:p-6">
        <h2 className="text-xl sm:text-2xl font-bold mb-4 sm:mb-6 text-gray-900">Havi Összesítés</h2>

        <div className="mb-4 sm:mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Hónap kiválasztása
          </label>
          <input
            type="month"
            value={currentMonth}
            onChange={(e) => setCurrentMonth(e.target.value)}
            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
          />
        </div>

        {loading ? (
          <div className="text-center py-12 text-gray-500">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-sky-500 mb-2"></div>
            <p>Betöltés...</p>
          </div>
        ) : (
          <>
            {currentMonth && (
              <>
                {/* Desktop View */}
                <div className="hidden md:block space-y-2 mb-6">
                  <div className="grid grid-cols-5 gap-4 p-4 bg-gradient-to-r from-sky-500 to-blue-500 text-white font-semibold text-sm rounded-lg shadow-md">
                    <div>Dátum</div>
                    <div>Feladat</div>
                    <div>Megjegyzés</div>
                    <div className="text-right">Ledolgozott</div>
                    <div className="text-right">Ledolgozható</div>
                  </div>
                  {getAllDaysInMonth().map((log) => {
                    const weekend = isWeekend(log.date);
                    const dayLogs = detailedLogs.filter(dl => dl.date === log.date);
                    
                    return (
                      <div key={log.date}>
                        <div
                          className={`grid grid-cols-5 gap-4 p-4 rounded-lg border transition ${
                            weekend
                              ? 'bg-amber-50 border-amber-200 hover:bg-amber-100'
                              : 'bg-white border-gray-200 hover:bg-gray-50'
                          }`}
                        >
                          <div className="flex flex-col">
                            <span className={`font-semibold ${
                              weekend ? 'text-amber-900' : 'text-gray-900'
                            }`}>
                              {log.date}
                            </span>
                            <span className={`text-xs mt-0.5 ${
                              weekend ? 'text-amber-700 font-medium' : 'text-gray-500'
                            }`}>
                              {getDayName(log.date)}
                            </span>
                          </div>
                          <div className="text-gray-700">
                            {dayLogs.length > 0 ? (
                              <div className="space-y-1">
                                {dayLogs.map(dl => {
                                  const logTypeLabels: Record<string, string> = {
                                    project: dl.project_name || 'Projekt',
                                    vacation: 'Szabadság',
                                    sick_leave: 'Betegség',
                                    article_writing: 'Cikkírás',
                                    presentation: 'Előadás',
                                    day_off: 'Szabadnap',
                                    mandatory_training: 'Kötelező továbbképzés',
                                    administration: 'Adminisztráció',
                                    flat_rate_phone: 'Átalánydíjas telefon',
                                    flat_rate_letter: 'Átalánydíjas levél',
                                    management_flat_rate: 'Vezetői feladatok átalánydíjas',
                                    management_expert: 'Vezetői feladatok szakértői',
                                    management_other: 'Vezetői feladatok egyéb',
                                    other: 'Egyéb'
                                  };
                                  return (
                                    <div key={dl.id} className="text-sm">
                                      {logTypeLabels[dl.log_type]}
                                    </div>
                                  );
                                })}
                              </div>
                            ) : '-'}
                          </div>
                          <div className="text-gray-600 italic text-sm">
                            {dayLogs.length > 0 ? (
                              <div className="space-y-1">
                                {dayLogs.map(dl => (
                                  <div key={dl.id}>
                                    {dl.comments || '-'}
                                  </div>
                                ))}
                              </div>
                            ) : '-'}
                          </div>
                          <div className="text-right font-semibold text-sky-600 self-center">
                            {log.total_hours.toFixed(1)} óra
                          </div>
                          <div className={`text-right font-medium self-center ${
                            weekend ? 'text-amber-600' : 'text-gray-600'
                          }`}>
                            {log.available_hours.toFixed(1)} óra
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Mobile View */}
                <div className="md:hidden space-y-3 mb-6">
                  {getAllDaysInMonth().map((log) => {
                    const weekend = isWeekend(log.date);
                    const dayLogs = detailedLogs.filter(dl => dl.date === log.date);
                    
                    return (
                      <div 
                        key={log.date}
                        className={`rounded-lg border shadow-sm overflow-hidden ${
                          weekend
                            ? 'bg-amber-50 border-amber-200'
                            : 'bg-white border-gray-200'
                        }`}
                      >
                        {/* Date Header */}
                        <div className={`px-4 py-3 font-semibold flex justify-between items-center ${
                          weekend 
                            ? 'bg-amber-100 text-amber-900' 
                            : 'bg-gradient-to-r from-sky-500 to-blue-500 text-white'
                        }`}>
                          <div>
                            <div className="text-base">{log.date}</div>
                            <div className={`text-xs mt-0.5 font-normal ${
                              weekend ? 'text-amber-700' : 'text-sky-100'
                            }`}>
                              {getDayName(log.date)}
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-lg font-bold">{log.total_hours.toFixed(1)}</div>
                            <div className={`text-xs font-normal ${
                              weekend ? 'text-amber-700' : 'text-sky-100'
                            }`}>
                              / {log.available_hours.toFixed(1)} óra
                            </div>
                          </div>
                        </div>
                        
                        {/* Content */}
                        <div className="px-4 py-3 space-y-3">
                          {dayLogs.length > 0 ? (
                             dayLogs.map(dl => {
                              const logTypeLabels: Record<string, string> = {
                                project: dl.project_name || 'Projekt',
                                vacation: 'Szabadság',
                                sick_leave: 'Betegség',
                                article_writing: 'Cikkírás',
                                presentation: 'Előadás',
                                day_off: 'Szabadnap',
                                mandatory_training: 'Kötelező továbbképzés',
                                administration: 'Adminisztráció',
                                flat_rate_phone: 'Átalánydíjas telefon',
                                flat_rate_letter: 'Átalánydíjas levél',
                                management_flat_rate: 'Vezetői feladatok átalánydíjas',
                                management_expert: 'Vezetői feladatok szakértői',
                                management_other: 'Vezetői feladatok egyéb',
                                other: 'Egyéb'
                              };
                              return (
                                <div key={dl.id} className="space-y-1.5">
                                  <div className="flex items-start gap-2">
                                    <div className="w-2 h-2 rounded-full bg-sky-500 mt-1.5 flex-shrink-0"></div>
                                    <div className="flex-1">
                                      <div className="font-medium text-gray-900 text-sm">
                                        {logTypeLabels[dl.log_type]}
                                      </div>
                                      {dl.comments && (
                                        <div className="text-xs text-gray-600 italic mt-1">
                                          {dl.comments}
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              );
                            })
                          ) : (
                            <div className="text-sm text-gray-400 italic text-center py-2">
                              Nincs rögzített munkaidő
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="border-t pt-4 sm:pt-6 mt-6">
                  <div className="bg-gradient-to-br from-sky-50 to-blue-50 p-4 sm:p-6 rounded-xl border border-sky-200 shadow-sm">
                    <div className="space-y-4">
                      <div className="flex justify-between items-baseline">
                        <span className="text-sm sm:text-base font-semibold text-gray-700">Havi ledolgozott:</span>
                        <div className="flex items-baseline gap-1.5">
                          <span className="text-2xl sm:text-3xl font-bold text-sky-600">
                            {getTotalHours().toFixed(1)}
                          </span>
                          <span className="text-base sm:text-lg text-gray-600">óra</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-baseline border-t border-sky-200 pt-4">
                        <span className="text-sm sm:text-base font-semibold text-gray-700">Havi ledolgozható:</span>
                        <div className="flex items-baseline gap-1.5">
                          <span className="text-2xl sm:text-3xl font-bold text-blue-600">
                            {totalAvailableHours.toFixed(1)}
                          </span>
                          <span className="text-base sm:text-lg text-gray-600">óra</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}
          </>
        )}
      </Card>
    </div>
  );
}
