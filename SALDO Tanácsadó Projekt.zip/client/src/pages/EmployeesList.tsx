import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Switch } from '../components/ui/switch';
import { User } from '../lib/api';

interface EmployeesListProps {
  employees: User[];
  loading: boolean;
  onResetPassword: (id: number) => Promise<void>;
  onEdit: (employee: User) => void;
  onDelete: (id: number) => Promise<void>;
  onToggleAdmin: (id: number, isAdmin: boolean) => Promise<void>;
}

export function EmployeesList({
  employees,
  loading,
  onResetPassword,
  onEdit,
  onDelete,
  onToggleAdmin
}: EmployeesListProps) {
  if (loading && employees.length === 0) {
    return (
      <Card className="p-6">
        <p className="text-muted-foreground">Betöltés...</p>
      </Card>
    );
  }

  if (employees.length === 0) {
    return (
      <Card className="p-6">
        <p className="text-muted-foreground">Még nincs dolgozó.</p>
      </Card>
    );
  }

  return (
    <Card className="p-4 sm:p-6">
      <h2 className="text-lg sm:text-xl font-bold mb-4 sm:mb-6 text-foreground">Dolgozók</h2>
      <div className="overflow-x-auto -mx-2 sm:mx-0">
        <table className="w-full min-w-full">
          <thead className="border-b">
            <tr>
              <th className="text-left py-2 sm:py-3 px-2 sm:px-4 font-semibold text-foreground text-xs sm:text-sm">
                Név
              </th>
              <th className="text-left py-2 sm:py-3 px-2 sm:px-4 font-semibold text-foreground text-xs sm:text-sm">
                E-mail
              </th>
              <th className="text-left py-2 sm:py-3 px-2 sm:px-4 font-semibold text-foreground text-xs sm:text-sm">
                Admin
              </th>
              <th className="text-left py-2 sm:py-3 px-2 sm:px-4 font-semibold text-foreground text-xs sm:text-sm">
                Műveletek
              </th>
            </tr>
          </thead>
          <tbody>
            {employees.map((employee) => (
              <tr
                key={employee.id}
                className="border-b hover:bg-muted/50"
              >
                <td className="py-2 sm:py-3 px-2 sm:px-4 text-foreground text-xs sm:text-sm">{employee.name}</td>
                <td className="py-2 sm:py-3 px-2 sm:px-4 text-foreground text-xs sm:text-sm">{employee.email}</td>
                <td className="py-2 sm:py-3 px-2 sm:px-4">
                  <Switch
                    checked={employee.is_admin === 1}
                    onCheckedChange={(checked) => onToggleAdmin(employee.id, checked)}
                    disabled={loading}
                  />
                </td>
                <td className="py-2 sm:py-3 px-2 sm:px-4">
                  <div className="flex gap-1 sm:gap-2 flex-wrap">
                    <Button
                      onClick={() => onEdit(employee)}
                      size="sm"
                      variant="outline"
                      className="text-xs sm:text-sm"
                      disabled={loading}
                    >
                      Módosítás
                    </Button>
                    <Button
                      onClick={() => onDelete(employee.id)}
                      size="sm"
                      variant="destructive"
                      className="text-xs sm:text-sm"
                      disabled={loading}
                    >
                      Törlés
                    </Button>
                    <Button
                      onClick={() => onResetPassword(employee.id)}
                      size="sm"
                      variant="outline"
                      className="text-xs sm:text-sm"
                      disabled={loading}
                    >
                      Jelszó reset
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}
