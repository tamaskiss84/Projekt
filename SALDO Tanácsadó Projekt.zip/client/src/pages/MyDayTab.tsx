import { useState, useEffect } from 'react';
import { Card } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Button } from '../components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Slider } from '../components/ui/slider';
import { Textarea } from '../components/ui/textarea';
import { api } from '../lib/api';
import { formatDate } from '../lib/date';

import type { LogType } from '../lib/api';

interface DayLog {
  id: number;
  project_id: number | null;
  project_name: string | null;
  hours: number;
  log_type: LogType;
  comments?: string | null;
}

interface Project {
  id: number;
  name: string;
  project_id?: string;
  project_group_name?: string | null;
  target_hours?: number;
}

interface MyDayTabProps {
  initialDate?: string;
  projects?: Project[];
  onDateChange?: (date: string) => void;
  onLogSubmitted?: () => void;
}

export function MyDayTab({ initialDate, projects: propProjects, onDateChange, onLogSubmitted }: MyDayTabProps = {}) {
  const [selectedDate, setSelectedDate] = useState('');
  const [logs, setLogs] = useState<DayLog[]>([]);
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editHours, setEditHours] = useState('');
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedProject, setSelectedProject] = useState('');
   const [hours, setHours] = useState(1);
  const [submitLoading, setSubmitLoading] = useState(false);
  const [logType, setLogType] = useState<LogType>('project');
  const [comments, setComments] = useState('');

  useEffect(() => {
    if (initialDate) {
      setSelectedDate(initialDate);
    } else {
      setSelectedDate(formatDate(new Date()));
    }
  }, [initialDate]);

  useEffect(() => {
    if (propProjects) {
      setProjects(propProjects);
      if (propProjects.length > 0) {
        setSelectedProject(propProjects[0].id.toString());
      }
    } else {
      loadProjects();
    }
  }, [propProjects]);

  useEffect(() => {
    if (selectedDate) {
      loadDayLogs();
      if (onDateChange) {
        onDateChange(selectedDate);
      }
    }
  }, [selectedDate]);

  const loadProjects = async () => {
    try {
      const data = await api.getMyProjects();
      setProjects(data);
      if (data.length > 0) {
        setSelectedProject(data[0].id.toString());
      }
    } catch (err) {
      console.error('Error loading projects:', err);
    }
  };

  const loadDayLogs = async () => {
    try {
      setLoading(true);
      const data = await api.getLogsForDate(selectedDate);
      setLogs(data.logs || []);
    } catch (err) {
      console.error('Error loading day logs:', err);
      setLogs([]);
    } finally {
      setLoading(false);
    }
  };

  const getTotalHours = () => {
    return logs.reduce((sum, log) => sum + log.hours, 0);
  };

   const getTargetHours = () => {
     if (!selectedDate) return 8.5;
     
     const date = new Date(selectedDate);
     const dayOfWeek = date.getDay();
     
     // Friday = 5, Saturday = 6, Sunday = 0
     if (dayOfWeek === 5) return 6;
     if (dayOfWeek === 6 || dayOfWeek === 0) return 0; // Weekend
     return 8.5; // Monday to Thursday
   };

   const getMaxSliderHours = () => {
     if (!selectedDate) return 8.5;
     
     const date = new Date(selectedDate);
     const dayOfWeek = date.getDay();
     
     // Use the maximum daily work hours as slider max
     if (dayOfWeek === 5) return 6; // Friday
     if (dayOfWeek === 6 || dayOfWeek === 0) return 8.5; // Weekend - allow 8.5 as fallback
     return 8.5; // Monday to Thursday
   };

  const targetHours = getTargetHours();
  const totalHours = getTotalHours();
  const difference = totalHours - targetHours;

  const handleEdit = (log: DayLog) => {
    setEditingId(log.id);
    setEditHours(log.hours.toString());
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditHours('');
  };

  const handleSaveEdit = async (id: number) => {
    try {
      const hours = parseFloat(editHours);
      if (isNaN(hours) || hours <= 0) {
        alert('Kérem adjon meg érvényes óraszámot');
        return;
      }

      await api.updateLog(id, hours);
      setEditingId(null);
      setEditHours('');
      await loadDayLogs();
    } catch (err) {
      console.error('Error updating log:', err);
      alert('Hiba történt a módosítás során');
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Biztosan törölni szeretné ezt a bejegyzést?')) {
      return;
    }

    try {
      await api.deleteLog(id);
      await loadDayLogs();
      if (onLogSubmitted) {
        onLogSubmitted();
      }
    } catch (err) {
      console.error('Error deleting log:', err);
      alert('Hiba történt a törlés során');
    }
  };

  const handleLogHours = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedDate) {
      alert('Válaszd ki a dátumot!');
      return;
    }

    if (logType === 'project' && !selectedProject) {
      alert('Válaszd ki a projektet!');
      return;
    }

    if (hours <= 0 || hours > 24) {
      alert('Az órák száma 0.5 és 24 között kell lennie!');
      return;
    }

    try {
      setSubmitLoading(true);
      const projectId = logType === 'project' ? Number(selectedProject) : null;
      await api.logHours(projectId, selectedDate, hours, logType, comments || undefined);
       await loadDayLogs();
       setHours(1);
       setLogType('project');
      setComments('');
      if (projects.length > 0) {
        setSelectedProject(projects[0].id.toString());
      }
      if (onLogSubmitted) {
        onLogSubmitted();
      }
    } catch (err) {
      console.error('Error logging hours:', err);
      alert('Hiba az óra rögzítésekor');
    } finally {
      setSubmitLoading(false);
    }
  };

  return (
    <div className="space-y-4 sm:space-y-8 max-w-4xl">
      <Card className="p-4 sm:p-6">
        <h2 className="text-lg sm:text-xl font-bold mb-4 sm:mb-6">Óra rögzítése</h2>

        <form onSubmit={handleLogHours} className="space-y-4 sm:space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nap kiválasztása
            </label>
            <Input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-full"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Típus
            </label>
            <Select
              value={logType}
              onValueChange={(value: any) => setLogType(value)}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Válassz típust" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="project">Projekt</SelectItem>
                <SelectItem value="flat_rate_phone">Átalánydíjas telefon</SelectItem>
                <SelectItem value="flat_rate_letter">Átalánydíjas levél</SelectItem>
                <SelectItem value="management_flat_rate">Vezetői feladatok átalánydíjas</SelectItem>
                <SelectItem value="management_expert">Vezetői feladatok szakértői</SelectItem>
                <SelectItem value="management_other">Vezetői feladatok egyéb</SelectItem>
                <SelectItem value="administration">Adminisztráció</SelectItem>
                <SelectItem value="vacation">Szabadság</SelectItem>
                <SelectItem value="sick_leave">Betegség</SelectItem>
                <SelectItem value="article_writing">Cikkírás</SelectItem>
                <SelectItem value="presentation">Előadás</SelectItem>
                <SelectItem value="day_off">Szabadnap</SelectItem>
                <SelectItem value="mandatory_training">Kötelező továbbképzés</SelectItem>
                <SelectItem value="other">Egyéb</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {logType === 'project' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Projekt
              </label>
              <Select
                value={selectedProject}
                onValueChange={setSelectedProject}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Válassz projektet" />
                </SelectTrigger>
                <SelectContent>
                  {projects.map((project) => (
                    <SelectItem key={project.id} value={project.id.toString()}>
                      {project.project_id ? `${project.project_id} - ${project.name}` : project.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-4">
              Ledolgozott órák: <span className="text-sky-600 font-bold text-lg">{hours.toFixed(2)}</span>
            </label>
            <Slider
              value={[hours]}
              onValueChange={(value) => setHours(value[0])}
              min={0.25}
              max={getMaxSliderHours()}
              step={0.25}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-gray-500 mt-2">
              <span>0.25</span>
              <span>{getMaxSliderHours().toFixed(1)}</span>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Megjegyzés (opcionális)
            </label>
            <Textarea
              value={comments}
              onChange={(e) => setComments(e.target.value)}
              placeholder="Írj megjegyzést..."
              className="w-full"
              rows={3}
            />
          </div>

          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-sky-500 to-blue-500 hover:from-sky-600 hover:to-blue-600 shadow-md"
            disabled={submitLoading}
          >
            {submitLoading ? 'Mentés...' : 'Mentés'}
          </Button>
        </form>
      </Card>

      <Card className="p-4 sm:p-6">
        <h2 className="text-lg sm:text-xl font-bold mb-4 sm:mb-6">Napi bejegyzések</h2>

        {loading ? (
          <div className="text-center py-8 text-gray-500">Betöltés...</div>
        ) : (
          <>
            {logs.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                Ezen a napon nincs rögzített óra.
              </div>
            ) : (
              <div className="space-y-3">
                {logs.map((log) => {
                  const logTypeLabels: Record<string, string> = {
                    project: log.project_name || 'Projekt',
                    vacation: 'Szabadság',
                    sick_leave: 'Betegség',
                    article_writing: 'Cikkírás',
                    presentation: 'Előadás',
                    day_off: 'Szabadnap',
                    mandatory_training: 'Kötelező továbbképzés',
                    administration: 'Adminisztráció',
                    flat_rate_phone: 'Átalánydíjas telefon',
                    flat_rate_letter: 'Átalánydíjas levél',
                    management_flat_rate: 'Vezetői feladatok átalánydíjas',
                    management_expert: 'Vezetői feladatok szakértői',
                    management_other: 'Vezetői feladatok egyéb',
                    other: 'Egyéb'
                  };

                  return (
                    <div
                      key={log.id}
                      className="flex flex-col p-3 sm:p-4 bg-gray-50 rounded-lg border border-gray-200 gap-2"
                    >
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                        <span className="font-medium text-gray-900 text-sm sm:text-base">{logTypeLabels[log.log_type]}</span>
                        
                        {editingId === log.id ? (
                          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                            <Input
                              type="number"
                              step="0.5"
                              value={editHours}
                              onChange={(e) => setEditHours(e.target.value)}
                              className="w-20 text-sm"
                            />
                            <span className="text-xs sm:text-sm text-gray-600">óra</span>
                            <Button size="sm" onClick={() => handleSaveEdit(log.id)} className="text-xs">
                              Mentés
                            </Button>
                            <Button size="sm" variant="outline" onClick={handleCancelEdit} className="text-xs">
                              Mégse
                            </Button>
                          </div>
                        ) : (
                          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                            <span className="text-base sm:text-lg font-semibold text-sky-600">
                              {log.hours.toFixed(1)} óra
                            </span>
                            <Button size="sm" variant="outline" onClick={() => handleEdit(log)} className="text-xs">
                              Módosítás
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => handleDelete(log.id)} className="text-xs">
                              Törlés
                            </Button>
                          </div>
                        )}
                      </div>
                      {log.comments && (
                        <div className="text-xs sm:text-sm text-gray-600 italic mt-1">
                          💬 {log.comments}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </>
        )}
      </Card>

      <div className="bg-gradient-to-br from-sky-50 to-blue-50 p-4 sm:p-6 rounded-lg border-2 border-sky-200 shadow-sm">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-baseline mb-2 gap-2">
          <span className="text-base sm:text-lg font-semibold text-gray-900">Összesen:</span>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl sm:text-4xl font-bold text-sky-600">
              {totalHours.toFixed(1)}
            </span>
            <span className="text-lg sm:text-xl text-gray-600">/ {targetHours} óra</span>
          </div>
        </div>

        {difference !== 0 && (
          <div className="mt-3 sm:mt-4">
            {difference > 0 ? (
              <p className="text-xs sm:text-sm text-green-600 font-medium">
                ✓ +{difference.toFixed(1)} óra túlmunka
              </p>
            ) : (
              <p className="text-xs sm:text-sm text-orange-600 font-medium">
                ⚠️ {Math.abs(difference).toFixed(1)} óra hiányzik
              </p>
            )}
          </div>
        )}

        {targetHours === 0 && (
          <p className="text-xs sm:text-sm text-gray-500 mt-3 sm:mt-4">
            Ez a nap hétvége.
          </p>
        )}
      </div>
    </div>
  );
}
