import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card } from '../components/ui/card';
import { api, WorkLogWithProject } from '../lib/api';

interface WorkLogWithActions extends WorkLogWithProject {
  isEditing?: boolean;
  editingHours?: number;
}

export function WorkLogsTable() {
  const [logs, setLogs] = useState<WorkLogWithActions[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Filters
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedProject, setSelectedProject] = useState('');

  const loadLogs = async () => {
    try {
      setLoading(true);
      setError('');
      setSuccess('');
      const projectId = selectedProject ? Number(selectedProject) : undefined;
      const data = await api.getAllLogs(startDate, endDate, projectId);
      setLogs(data.map((log: WorkLogWithProject) => ({ ...log, isEditing: false })));
    } catch (err) {
      setError('Hiba a naplók betöltésekor');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleEditStart = (logId: number, currentHours: number) => {
    setLogs(logs.map(log => 
      log.id === logId 
        ? { ...log, isEditing: true, editingHours: currentHours }
        : log
    ));
  };

  const handleEditCancel = (logId: number) => {
    setLogs(logs.map(log =>
      log.id === logId
        ? { ...log, isEditing: false, editingHours: undefined }
        : log
    ));
  };

  const handleEditSave = async (logId: number) => {
    const log = logs.find(l => l.id === logId);
    if (!log || log.editingHours === undefined) return;

    if (isNaN(log.editingHours) || log.editingHours <= 0 || log.editingHours > 24) {
      setError('Az órák száma 0.5 és 24 között kell lennie');
      return;
    }

    try {
      setError('');
      setSuccess('');
      await api.updateLog(logId, log.editingHours);
      setSuccess('Napló sikeresen frissítve');
      await loadLogs();
    } catch (err) {
      setError('Hiba a napló frissítésekor');
      console.error(err);
    }
  };

  const handleDelete = async (logId: number) => {
    if (!window.confirm('Biztosan törölni szeretnéd ezt a naplót?')) {
      return;
    }

    try {
      setError('');
      setSuccess('');
      await api.deleteLog(logId);
      setSuccess('Napló sikeresen törölve');
      await loadLogs();
    } catch (err) {
      setError('Hiba a napló törléskor');
      console.error(err);
    }
  };

  const handleFilter = () => {
    loadLogs();
  };

  const totalHours = logs.reduce((sum, log) => sum + log.hours, 0);

  return (
    <div className="max-w-6xl mx-auto px-2 sm:px-4 py-4 sm:py-8 space-y-4 sm:space-y-6">
      <div>
        <h2 className="text-xl sm:text-2xl font-bold mb-4 sm:mb-6">Munkaidő naplók</h2>

        {error && (
          <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
            {error}
          </div>
        )}

        {success && (
          <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg text-green-700">
            {success}
          </div>
        )}

        <Card className="p-4 sm:p-6 mb-4 sm:mb-6">
          <h3 className="text-base sm:text-lg font-semibold mb-3 sm:mb-4">Szűrés</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Kezdő dátum
              </label>
              <Input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Végdátum
              </label>
              <Input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>
          </div>

          <Button
            onClick={handleFilter}
            className="mt-4 bg-gradient-to-r from-sky-500 to-blue-500 hover:from-sky-600 hover:to-blue-600 shadow-md w-full md:w-auto"
            disabled={loading}
          >
            {loading ? 'Szűrés...' : 'Szűrés'}
          </Button>
        </Card>

        {logs.length > 0 && (
          <div>
            <div className="overflow-x-auto -mx-2 sm:mx-0">
              <table className="w-full border-collapse min-w-full">
                <thead>
                  <tr className="bg-gray-100 border-b-2 border-gray-300">
                    <th className="px-2 sm:px-4 py-2 sm:py-3 text-left font-semibold text-gray-700 text-xs sm:text-sm">Dátum</th>
                    <th className="px-2 sm:px-4 py-2 sm:py-3 text-left font-semibold text-gray-700 text-xs sm:text-sm">Projekt</th>
                    <th className="px-2 sm:px-4 py-2 sm:py-3 text-center font-semibold text-gray-700 text-xs sm:text-sm">Órák</th>
                    <th className="px-2 sm:px-4 py-2 sm:py-3 text-center font-semibold text-gray-700 text-xs sm:text-sm">Műveletek</th>
                  </tr>
                </thead>
                <tbody>
                  {logs.map((log) => (
                    <tr key={log.id} className="border-b border-gray-200 hover:bg-gray-50">
                      <td className="px-2 sm:px-4 py-2 sm:py-3 text-xs sm:text-sm">
                        {new Date(log.date).toLocaleDateString('hu-HU')}
                      </td>
                      <td className="px-2 sm:px-4 py-2 sm:py-3 text-xs sm:text-sm">{log.project_name}</td>
                      <td className="px-2 sm:px-4 py-2 sm:py-3 text-center">
                        {log.isEditing ? (
                          <input
                            type="number"
                            min="0.5"
                            max="24"
                            step="0.5"
                            value={log.editingHours}
                            onChange={(e) =>
                              setLogs(logs.map(l =>
                                l.id === log.id
                                  ? { ...l, editingHours: parseFloat(e.target.value) || 0 }
                                  : l
                              ))
                            }
                            className="w-20 px-2 py-1 border border-gray-300 rounded text-center text-xs sm:text-sm"
                          />
                        ) : (
                          <span className="font-semibold text-sky-600 text-sm sm:text-base">
                            {log.hours.toFixed(1)}
                          </span>
                        )}
                      </td>
                      <td className="px-2 sm:px-4 py-2 sm:py-3 text-center">
                        <div className="flex gap-1 sm:gap-2 justify-center flex-wrap">
                          {log.isEditing ? (
                            <>
                              <button
                                onClick={() => handleEditSave(log.id)}
                                className="px-2 sm:px-3 py-1 bg-green-600 text-white rounded text-xs sm:text-sm hover:bg-green-700 transition"
                              >
                                Mentés
                              </button>
                              <button
                                onClick={() => handleEditCancel(log.id)}
                                className="px-2 sm:px-3 py-1 bg-gray-400 text-white rounded text-xs sm:text-sm hover:bg-gray-500 transition"
                              >
                                Mégse
                              </button>
                            </>
                          ) : (
                            <>
                              <button
                                onClick={() => handleEditStart(log.id, log.hours)}
                                className="px-2 sm:px-3 py-1 bg-blue-600 text-white rounded text-xs sm:text-sm hover:bg-blue-700 transition"
                              >
                                Szerkesztés
                              </button>
                              <button
                                onClick={() => handleDelete(log.id)}
                                className="px-2 sm:px-3 py-1 bg-red-600 text-white rounded text-xs sm:text-sm hover:bg-red-700 transition"
                              >
                                Törlés
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <Card className="p-4 sm:p-6 mt-4 sm:mt-6 bg-gradient-to-br from-sky-50 to-blue-50 border-sky-200">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <h3 className="text-base sm:text-lg font-semibold text-gray-900">
                  Összes ledolgozott óra
                </h3>
                <div className="text-left sm:text-right">
                  <p className="text-3xl sm:text-4xl font-bold text-sky-600">
                    {totalHours.toFixed(1)}
                  </p>
                  <p className="text-xs sm:text-sm text-gray-600 mt-1">
                    {logs.length} napló
                  </p>
                </div>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
