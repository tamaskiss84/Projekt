import { useState, useEffect } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card } from '../components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Slider } from '../components/ui/slider';
import { api } from '../lib/api';
import { formatDate } from '../lib/date';
import { WorkLogsTable } from './WorkLogsTable';
import { MyDayTab } from './MyDayTab';
import { MonthlySummaryTab } from './MonthlySummaryTab';
import { ProjectsTab } from './ProjectsTab';

interface EmployeeLog {
  user_id: number;
  user_name: string;
  total_hours: number;
}

interface Project {
  id: number;
  name: string;
  project_group_name?: string | null;
  target_hours?: number;
  employee_logs?: EmployeeLog[];
}

export function EmployeeDashboard() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [activeTab, setActiveTab] = useState<'log' | 'monthly' | 'projects' | 'logs' | 'password'>('log');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Log form
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedProject, setSelectedProject] = useState('');
  const [hours, setHours] = useState(4);

  // Daily stats
  const [dailyTotal, setDailyTotal] = useState(0);
  const [dailyLogs, setDailyLogs] = useState<any[]>([]);

  // Password form
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  useEffect(() => {
    loadProjects();
    setSelectedDate(formatDate(new Date()));
  }, []);

  useEffect(() => {
    if (selectedDate) {
      loadDailyTotal();
    }
  }, [selectedDate]);

  const loadProjects = async () => {
    try {
      setError('');
      const data = await api.getMyProjects();
      setProjects(data);
      if (data.length > 0) {
        setSelectedProject(data[0].id.toString());
      }
    } catch (err) {
      setError('Hiba a projektek betöltésekor');
      console.error(err);
    }
  };

  const loadDailyTotal = async () => {
    try {
      const data = await api.getLogsForDate(selectedDate);
      setDailyTotal(data.totalHours || 0);
      setDailyLogs(data.logs || []);
    } catch (err) {
      console.error('Error loading daily total:', err);
      setDailyTotal(0);
      setDailyLogs([]);
    }
  };

  const handleLogHours = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject || !selectedDate) {
      setError('Válaszd ki a projektet és a dátumot!');
      return;
    }

    try {
      setLoading(true);
      setError('');
      await api.logHours(Number(selectedProject), selectedDate, hours);
      await loadDailyTotal();
      setHours(4);
      if (projects.length > 0) {
        setSelectedProject(projects[0].id.toString());
      }
    } catch (err) {
      setError('Hiba az óra rögzítésekor');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!oldPassword || !newPassword || !confirmPassword) {
      setError('Tölts ki minden mezőt!');
      return;
    }

    if (newPassword !== confirmPassword) {
      setError('Az új jelszavak nem egyeznek!');
      return;
    }

    if (newPassword.length < 4) {
      setError('Az új jelszónak legalább 4 karakter hosszúnak kell lennie!');
      return;
    }

    try {
      setLoading(true);
      setError('');
      await api.changePassword(oldPassword, newPassword);
      setOldPassword('');
      setNewPassword('');
      setConfirmPassword('');
      // Show success message
      alert('Jelszó sikeresen megváltoztatva!');
    } catch (err) {
      setError('Hiba a jelszó megváltoztatásakor');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (loading && projects.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-8">
        <Card className="p-6 text-center">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mb-2"></div>
          <p className="text-gray-600">Betöltés...</p>
        </Card>
      </div>
    );
  }

  if (projects.length === 0 && !loading) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-8">
        <Card className="p-6 text-center">
          <div className="text-4xl mb-4">📋</div>
          <p className="text-gray-600 mb-4 font-medium">Nincs elérhető projekt.</p>
          <p className="text-sm text-gray-500">
            Vedd fel a kapcsolatot a vezetővel projekt csoport hozzárendeléséhez.
          </p>
        </Card>
      </div>
    );
  }

  return (
    <div>
      <div className="max-w-6xl mx-auto px-2 sm:px-4 py-4 sm:py-8">
        <div className="flex gap-2 sm:gap-4 mb-4 sm:mb-8 overflow-x-auto pb-2 scrollbar-hide px-1">
          <button
            onClick={() => setActiveTab('log')}
            className={`px-3 sm:px-4 py-2 text-sm sm:text-base font-medium rounded-lg transition-all whitespace-nowrap shadow-sm ${
              activeTab === 'log'
                ? 'bg-gradient-to-r from-sky-500 to-blue-500 text-white shadow-lg scale-105'
                : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-200 hover:border-sky-300'
            }`}
          >
            Munkaidő rögzítés
          </button>
          <button
            onClick={() => setActiveTab('monthly')}
            className={`px-3 sm:px-4 py-2 text-sm sm:text-base font-medium rounded-lg transition-all whitespace-nowrap shadow-sm ${
              activeTab === 'monthly'
                ? 'bg-gradient-to-r from-sky-500 to-blue-500 text-white shadow-lg scale-105'
                : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-200 hover:border-sky-300'
            }`}
          >
            Havi Összesítés
          </button>
          <button
            onClick={() => setActiveTab('projects')}
            className={`px-3 sm:px-4 py-2 text-sm sm:text-base font-medium rounded-lg transition-all whitespace-nowrap shadow-sm ${
              activeTab === 'projects'
                ? 'bg-gradient-to-r from-sky-500 to-blue-500 text-white shadow-lg scale-105'
                : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-200 hover:border-sky-300'
            }`}
          >
            Projektek
          </button>
          <button
            onClick={() => setActiveTab('logs')}
            className={`px-3 sm:px-4 py-2 text-sm sm:text-base font-medium rounded-lg transition-all whitespace-nowrap shadow-sm ${
              activeTab === 'logs'
                ? 'bg-gradient-to-r from-sky-500 to-blue-500 text-white shadow-lg scale-105'
                : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-200 hover:border-sky-300'
            }`}
          >
            Naplók
          </button>
          <button
            onClick={() => setActiveTab('password')}
            className={`px-3 sm:px-4 py-2 text-sm sm:text-base font-medium rounded-lg transition-all whitespace-nowrap shadow-sm ${
              activeTab === 'password'
                ? 'bg-gradient-to-r from-sky-500 to-blue-500 text-white shadow-lg scale-105'
                : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-200 hover:border-sky-300'
            }`}
          >
            Jelszó módosítás
          </button>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
            {error}
          </div>
        )}

        {activeTab === 'log' && (
          <MyDayTab 
            initialDate={selectedDate}
            projects={projects}
            onDateChange={setSelectedDate}
            onLogSubmitted={loadProjects}
          />
        )}

        {activeTab === 'monthly' && (
          <MonthlySummaryTab />
        )}

        {activeTab === 'projects' && (
          <ProjectsTab />
        )}

        {activeTab === 'logs' && (
          <WorkLogsTable />
        )}

        {activeTab === 'password' && (
          <Card className="p-4 sm:p-6 max-w-2xl">
            <h2 className="text-lg sm:text-xl font-bold mb-4 sm:mb-6">Jelszó módosítás</h2>
            <form onSubmit={handleChangePassword} className="space-y-4 max-w-md">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Régi jelszó
                </label>
                <Input
                  type="password"
                  value={oldPassword}
                  onChange={(e) => setOldPassword(e.target.value)}
                  placeholder="••••••••"
                  disabled={loading}
                  required
                  autoComplete="current-password"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Új jelszó
                </label>
                <Input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="••••••••"
                  disabled={loading}
                  required
                  autoComplete="new-password"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Legalább 4 karakter
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Új jelszó megerősítése
                </label>
                <Input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  disabled={loading}
                  required
                  autoComplete="new-password"
                />
              </div>

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-sky-500 to-blue-500 hover:from-sky-600 hover:to-blue-600 shadow-md"
                disabled={loading}
              >
                {loading ? 'Mentés...' : 'Jelszó módosítása'}
              </Button>
            </form>
          </Card>
        )}
      </div>
    </div>
  );
}
