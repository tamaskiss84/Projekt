import { useState } from 'react';
import { Button } from './ui/button';

interface CalendarViewProps {
  selectedDate: string;
  onDateSelect: (date: string) => void;
}

export function CalendarView({ selectedDate, onDateSelect }: CalendarViewProps) {
  const today = new Date();
  const [currentYear, setCurrentYear] = useState(today.getFullYear());
  const [currentMonth, setCurrentMonth] = useState(today.getMonth());

  const monthNames = [
    'Január', 'Február', 'Március', 'Április', 'Május', 'Június',
    'Július', 'Augusztus', 'Szeptember', 'Október', 'November', 'December'
  ];

  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();
  const adjustedFirstDay = firstDayOfMonth === 0 ? 6 : firstDayOfMonth - 1;

  const previousMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
  };

  const nextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
  };

  const formatDateString = (day: number) => {
    const month = (currentMonth + 1).toString().padStart(2, '0');
    const dayStr = day.toString().padStart(2, '0');
    return `${currentYear}-${month}-${dayStr}`;
  };

  const isToday = (day: number) => {
    return day === today.getDate() && 
           currentMonth === today.getMonth() && 
           currentYear === today.getFullYear();
  };

  const isSelected = (day: number) => {
    return formatDateString(day) === selectedDate;
  };

  const days = [];
  for (let i = 0; i < adjustedFirstDay; i++) {
    days.push(<div key={`empty-${i}`} className="aspect-square" />);
  }

  for (let day = 1; day <= daysInMonth; day++) {
    const dateStr = formatDateString(day);
    const isTodayDate = isToday(day);
    const isSelectedDate = isSelected(day);

    days.push(
      <button
        key={day}
        onClick={() => onDateSelect(dateStr)}
        className={`
          aspect-square p-2 rounded-lg text-sm font-medium transition-all
          ${isSelectedDate 
            ? 'bg-indigo-600 text-white shadow-lg scale-105' 
            : isTodayDate
            ? 'bg-indigo-100 text-indigo-900 hover:bg-indigo-200'
            : 'hover:bg-gray-100 text-gray-700'
          }
        `}
      >
        {day}
      </button>
    );
  }

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4">
      <div className="flex items-center justify-between mb-4">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={previousMonth}
        >
          ←
        </Button>
        <h3 className="text-lg font-semibold">
          {monthNames[currentMonth]} {currentYear}
        </h3>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={nextMonth}
        >
          →
        </Button>
      </div>

      <div className="grid grid-cols-7 gap-2 mb-2">
        {['H', 'K', 'Sze', 'Cs', 'P', 'Szo', 'V'].map((day) => (
          <div key={day} className="text-center text-xs font-semibold text-gray-600 pb-2">
            {day}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-2">
        {days}
      </div>
    </div>
  );
}
