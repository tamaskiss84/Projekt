import { useState, useRef } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import * as XLSX from 'xlsx';

interface Employee {
  id: number;
  email: string;
  name: string;
}

interface ImportedProjectGroup {
  name: string;
  member_emails: string[];
}

interface ProjectGroupImportProps {
  employees: Employee[];
  onImportComplete: () => void;
}

export function ProjectGroupImport({ employees, onImportComplete }: ProjectGroupImportProps) {
  const [importing, setImporting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setError('');
    setSuccess('');
    setImporting(true);

    try {
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data);
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);

      const importedGroups: ImportedProjectGroup[] = [];

      for (const row of jsonData as any[]) {
        const groupName = row['Csoport neve'] || row['Group Name'] || row['name'];
        const memberEmails = row['Dolgozók email címei'] || row['Employee Emails'] || row['members'];

        if (!groupName) {
          continue;
        }

        // Parse emails - handle both comma-separated and already parsed arrays
        let emailArray: string[] = [];
        if (memberEmails) {
          if (Array.isArray(memberEmails)) {
            emailArray = memberEmails.map((s: any) => String(s).trim());
          } else {
            emailArray = String(memberEmails).split(/[,;]/).map((s: string) => s.trim()).filter(s => s.length > 0);
          }
        }

        importedGroups.push({
          name: String(groupName),
          member_emails: emailArray
        });
      }

      if (importedGroups.length === 0) {
        setError('Nem található importálható projekt csoport a fájlban');
        setImporting(false);
        return;
      }

      // Import project groups via API
      const response = await fetch('/api/project-groups/import', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ groups: importedGroups })
      });

      if (!response.ok) {
        throw new Error('Hiba az import során');
      }

      setSuccess(`Sikeresen importálva ${importedGroups.length} projekt csoport`);
      onImportComplete();
      
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (err) {
      console.error('Import error:', err);
      setError('Hiba történt a fájl beolvasása során');
    } finally {
      setImporting(false);
    }
  };

  const handleDownloadTemplate = () => {
    try {
      console.log('Starting template download...');
      const workbook = XLSX.utils.book_new();
      
      // Create sample data
      const sampleData = [
        {
          'Csoport neve': 'Webfejlesztés',
          'Dolgozók email címei': 'kovacs.peter@example.com, nagy.eva@example.com'
        },
        {
          'Csoport neve': 'Mobilfejlesztés',
          'Dolgozók email címei': 'szabo.istvan@example.com'
        },
        {
          'Csoport neve': 'Backend',
          'Dolgozók email címei': 'toth.maria@example.com, kiss.janos@example.com'
        }
      ];

      const worksheet = XLSX.utils.json_to_sheet(sampleData);
      
      // Set column widths
      worksheet['!cols'] = [
        { wch: 30 },
        { wch: 50 }
      ];

      XLSX.utils.book_append_sheet(workbook, worksheet, 'Projekt csoportok');
      
      console.log('Generating Excel file...');
      // Use XLSX.writeFile which handles the download automatically
      XLSX.writeFile(workbook, 'projekt_csoportok_import_minta.xlsx');
      
      console.log('Template file downloaded successfully');
    } catch (err) {
      console.error('Error downloading template:', err);
      setError('Hiba történt a minta fájl letöltése során');
    }
  };

  return (
    <Card className="p-4 sm:p-6">
      <h3 className="text-base sm:text-lg font-semibold mb-3 sm:mb-4">Projekt csoportok importálása</h3>
      
      <div className="space-y-3 sm:space-y-4">
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 sm:p-4">
          <h4 className="font-medium text-blue-900 mb-2 text-sm sm:text-base">ℹ️ Útmutató</h4>
          <p className="text-xs sm:text-sm text-blue-800 mb-2">Az Excel fájlnak a következő oszlopokat kell tartalmaznia:</p>
          <ul className="text-xs sm:text-sm text-blue-800 list-disc list-inside space-y-1">
            <li><strong>Csoport neve</strong> (kötelező) - A projekt csoport neve</li>
            <li><strong>Dolgozók email címei</strong> (opcionális) - Dolgozók email címei vesszővel vagy pontosvesszővel elválasztva</li>
          </ul>
          <div className="mt-3">
            <Button 
              onClick={handleDownloadTemplate}
              variant="outline"
              size="sm"
              className="text-blue-700 border-blue-300 hover:bg-blue-100 w-full sm:w-auto text-xs sm:text-sm"
            >
              📥 Minta fájl letöltése
            </Button>
          </div>
        </div>

        <div>
          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx,.xls"
            onChange={handleFileUpload}
            disabled={importing}
            className="block w-full text-xs sm:text-sm text-gray-500
              file:mr-2 sm:file:mr-4 file:py-2 file:px-3 sm:file:px-4
              file:rounded-md file:border-0
              file:text-xs sm:file:text-sm file:font-semibold
              file:bg-indigo-50 file:text-indigo-700
              hover:file:bg-indigo-100
              disabled:opacity-50"
          />
        </div>

        {error && (
          <div className="p-2 sm:p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-xs sm:text-sm">
            {error}
          </div>
        )}

        {success && (
          <div className="p-2 sm:p-3 bg-green-50 border border-green-200 rounded-lg text-green-700 text-xs sm:text-sm">
            {success}
          </div>
        )}

        {importing && (
          <div className="text-xs sm:text-sm text-gray-600">
            Importálás folyamatban...
          </div>
        )}
      </div>
    </Card>
  );
}
