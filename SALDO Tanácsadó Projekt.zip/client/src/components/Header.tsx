import { User } from '../lib/api';
import { Button } from './ui/button';
import { useState, useEffect } from 'react';

interface HeaderProps {
  user: User;
  onLogout: () => void;
  onRoleSwitch?: (role: 'manager' | 'employee') => void;
}

export function Header({ user, onLogout, onRoleSwitch }: HeaderProps) {
  const isAdmin = Boolean(user.is_admin);
  const roleLabel = user.role === 'manager' ? 'Admin nézet' : 'Dolgozói nézet';
  const [isVisible, setIsVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);
  
  console.log('Header user:', user);
  console.log('isAdmin:', isAdmin);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      // Only hide on mobile (768px and below)
      if (window.innerWidth <= 768) {
        if (currentScrollY > lastScrollY && currentScrollY > 10) {
          setIsVisible(false);
        } else {
          setIsVisible(true);
        }
      } else {
        setIsVisible(true);
      }
      
      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  return (
    <header className={`bg-gradient-to-r from-sky-500 to-blue-500 shadow-lg sticky top-0 z-50 backdrop-blur-sm transition-transform duration-300 ${
      isVisible ? 'translate-y-0' : '-translate-y-full'
    }`}>
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-3 sm:py-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div className="flex items-center gap-3">
            <img src="/logo.png" alt="SALDO" className="w-10 h-10 sm:w-12 sm:h-12 object-contain drop-shadow-md" />
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">SALDO</h1>
              <p className="text-xs text-sky-100 mt-0.5">Tanácsadó Projekt</p>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 w-full sm:w-auto">
            <div className="text-xs sm:text-sm text-white bg-white/10 px-3 py-2 rounded-lg backdrop-blur-sm">
              <p className="font-semibold">{user.name || user.email}</p>
              <p className="text-sky-100 text-xs">{isAdmin ? `${roleLabel}` : 'Dolgozó'}</p>
            </div>
            <div className="flex gap-2 w-full sm:w-auto">
              {isAdmin && (
                <Button 
                  onClick={() => onRoleSwitch?.(user.role === 'manager' ? 'employee' : 'manager')}
                  variant="outline" 
                  size="sm" 
                  className="text-xs sm:text-sm bg-white/95 text-sky-600 hover:bg-white border-white shadow-sm hover:shadow-md transition-all"
                >
                  {user.role === 'manager' ? '👤 Dolgozói nézet' : '⚙️ Admin nézet'}
                </Button>
              )}
              <Button
                onClick={onLogout}
                variant="outline"
                size="sm"
                className="text-xs sm:text-sm bg-white/95 text-sky-600 hover:bg-white border-white shadow-sm hover:shadow-md transition-all"
              >
                Kilépés
              </Button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
