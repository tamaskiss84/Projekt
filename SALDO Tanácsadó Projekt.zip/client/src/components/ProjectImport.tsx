import { useState, useRef } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import * as XLSX from 'xlsx';

interface ProjectGroup {
  id: number;
  name: string;
}

interface ImportedProject {
  name: string;
  project_id: string;
  target_hours: number | null;
  project_group_ids: number[];
}

interface ProjectImportProps {
  projectGroups: ProjectGroup[];
  onImportComplete: () => void;
}

export function ProjectImport({ projectGroups, onImportComplete }: ProjectImportProps) {
  const [importing, setImporting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    await processFile(file);
  };

  const processFile = async (file: File) => {
    if (!file.name.match(/\.(xlsx|xls)$/i)) {
      setError('Kérjük, Excel fájlt adjon meg (.xlsx vagy .xls)');
      return;
    }

    setError('');
    setSuccess('');
    setImporting(true);

    try {
       const data = await file.arrayBuffer();
       let workbook;
       try {
         const buffer = new Uint8Array(data);
         console.log('File size:', buffer.length, 'bytes');
         console.log('First bytes:', buffer.slice(0, 8));
         workbook = XLSX.read(buffer, { type: 'array', cellText: false });
       } catch (readErr) {
         console.error('Excel read error:', readErr);
         setError('Az Excel fájl nem olvasható. Kérjük, ellenőrizze, hogy érvényes Excel fájl-e.');
         setImporting(false);
         return;
       }

       if (!workbook.SheetNames || workbook.SheetNames.length === 0) {
         setError('Az Excel fájl nem tartalmaz munkalapokat');
         setImporting(false);
         return;
       }

       const worksheet = workbook.Sheets[workbook.SheetNames[0]];
       if (!worksheet) {
         setError('Az első munkalap nem olvasható');
         setImporting(false);
         return;
       }

       const jsonData = XLSX.utils.sheet_to_json(worksheet);

      const importedProjects: ImportedProject[] = [];

      for (const row of jsonData as any[]) {
        const projectName = row['Projekt neve'] || row['Name'] || row['name'];
        const projectId = row['Projekt azonosítója'] || row['Project ID'] || row['project_id'];
        const targetHours = row['Tervezett óraszám'] || row['Target Hours'] || row['target_hours'];
        const groupNames = row['Projekt csoportok'] || row['Project Groups'] || row['project_groups'];

        if (!projectName || !projectId) {
          continue;
        }

        // Parse group names - handle both comma-separated and already parsed arrays
        let groupNameArray: string[] = [];
        if (groupNames) {
          if (Array.isArray(groupNames)) {
            groupNameArray = groupNames.map((s: any) => String(s).trim());
          } else {
            groupNameArray = String(groupNames).split(/[,;]/).map((s: string) => s.trim()).filter(s => s.length > 0);
          }
        }
        
        const matchedGroupIds = groupNameArray
          .map(name => projectGroups.find(g => g.name.toLowerCase() === name.toLowerCase())?.id)
          .filter((id): id is number => id !== undefined);

        if (matchedGroupIds.length === 0) {
          console.warn(`Projekt "${projectName}" kihagyva - nem található egyező projekt csoport`);
          continue;
        }

        importedProjects.push({
          name: String(projectName),
          project_id: String(projectId),
          target_hours: targetHours ? Number(targetHours) : null,
          project_group_ids: matchedGroupIds
        });
      }

      if (importedProjects.length === 0) {
        setError('Nem található importálható projekt a fájlban');
        setImporting(false);
        return;
      }

      // Import projects via API
      const response = await fetch('/api/projects/import', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ projects: importedProjects })
      });

      if (!response.ok) {
        throw new Error('Hiba az import során');
      }

      setSuccess(`Sikeresen importálva ${importedProjects.length} projekt`);
      onImportComplete();
      
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (err) {
      console.error('Import error:', err);
      setError('Hiba történt a fájl beolvasása során');
    } finally {
      setImporting(false);
    }
  };

  const handleDrag = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const files = e.dataTransfer.files;
    if (files && files[0]) {
      processFile(files[0]);
    }
  };

  const handleDownloadTemplate = () => {
    try {
      console.log('Starting template download...');
      const workbook = XLSX.utils.book_new();
      
      // Create sample data
      const sampleData = [
        {
          'Projekt azonosítója': 'Munkaszám_0001',
          'Projekt neve': 'Weboldal fejlesztés',
          'Tervezett óraszám': 120,
          'Projekt csoportok': 'Webfejlesztés'
        },
        {
          'Projekt azonosítója': 'Munkaszám_0002',
          'Projekt neve': 'Mobilalkalmazás',
          'Tervezett óraszám': 200,
          'Projekt csoportok': 'Mobilfejlesztés, Backend'
        },
        {
          'Projekt azonosítója': 'Munkaszám_0003',
          'Projekt neve': 'API fejlesztés',
          'Tervezett óraszám': 80,
          'Projekt csoportok': 'Backend'
        }
      ];

      const worksheet = XLSX.utils.json_to_sheet(sampleData);
      
      // Set column widths
      worksheet['!cols'] = [
        { wch: 25 },
        { wch: 30 },
        { wch: 20 },
        { wch: 40 }
      ];

      XLSX.utils.book_append_sheet(workbook, worksheet, 'Projektek');
      
      console.log('Generating Excel file...');
      // Use XLSX.writeFile which handles the download automatically
      XLSX.writeFile(workbook, 'projektek_import_minta.xlsx');
      
      console.log('Template file downloaded successfully');
    } catch (err) {
      console.error('Error downloading template:', err);
      setError('Hiba történt a minta fájl letöltése során');
    }
  };

  return (
    <Card className="p-4 sm:p-6">
      <h3 className="text-base sm:text-lg font-semibold mb-3 sm:mb-4">Projektek importálása</h3>
      
      <div className="space-y-3 sm:space-y-4">
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 sm:p-4">
          <h4 className="font-medium text-blue-900 mb-2 text-sm sm:text-base">ℹ️ Útmutató</h4>
          <p className="text-xs sm:text-sm text-blue-800 mb-2">Az Excel fájlnak a következő oszlopokat kell tartalmaznia:</p>
          <ul className="text-xs sm:text-sm text-blue-800 list-disc list-inside space-y-1">
            <li><strong>Projekt azonosítója</strong> (kötelező) - Egyedi projekt azonosító (pl. Munkaszám_sorszám)</li>
            <li><strong>Projekt neve</strong> (kötelező) - A projekt neve</li>
            <li><strong>Tervezett óraszám</strong> (opcionális) - A projekt tervezett óraszáma számként</li>
            <li><strong>Projekt csoportok</strong> (kötelező) - Projekt csoportok nevei vesszővel vagy pontosvesszővel elválasztva</li>
          </ul>
          <div className="mt-3">
            <Button 
              onClick={handleDownloadTemplate}
              variant="outline"
              size="sm"
              className="text-blue-700 border-blue-300 hover:bg-blue-100 w-full sm:w-auto text-xs sm:text-sm"
            >
              📥 Minta fájl letöltése
            </Button>
          </div>
        </div>

        <div
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
          className={`relative border-2 border-dashed rounded-lg p-6 sm:p-8 text-center transition-colors ${
            dragActive
              ? 'border-indigo-500 bg-indigo-50'
              : 'border-gray-300 bg-gray-50'
          } ${importing ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx,.xls"
            onChange={handleFileUpload}
            disabled={importing}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed"
          />
          <div className="flex flex-col items-center justify-center">
            <svg
              className="w-8 h-8 sm:w-12 sm:h-12 mx-auto mb-2 sm:mb-3 text-gray-400"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 4v16m8-8H4"
              />
            </svg>
            <p className="text-xs sm:text-sm font-medium text-gray-700">
              Húzza ide az Excel fájlt vagy kattintson a kiválasztásához
            </p>
            <p className="text-xs text-gray-500 mt-1">
              .xlsx vagy .xls formátum
            </p>
          </div>
        </div>

        {error && (
          <div className="p-2 sm:p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-xs sm:text-sm">
            {error}
          </div>
        )}

        {success && (
          <div className="p-2 sm:p-3 bg-green-50 border border-green-200 rounded-lg text-green-700 text-xs sm:text-sm">
            {success}
          </div>
        )}

        {importing && (
          <div className="text-xs sm:text-sm text-gray-600">
            Importálás folyamatban...
          </div>
        )}
      </div>
    </Card>
  );
}
