import { useState, useEffect, useCallback } from 'react';
import { LoginForm } from './components/LoginForm';
import { Header } from './components/Header';
import { ManagerDashboard } from './pages/ManagerDashboard';
import { EmployeeDashboard } from './pages/EmployeeDashboard';
import { api, type User } from './lib/api';
import { saveAuth, getAuth, clearAuth } from './lib/auth';
import { useIdleTimeout } from './lib/useIdleTimeout';

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const auth = getAuth();
    if (auth) {
      setUser(auth.user);
    }
    setLoading(false);
  }, []);

  const handleLogin = async (email: string, password: string) => {
    try {
      setLoading(true);
      setError('');
      const response = await api.login(email, password);
      saveAuth(response.token, response.user);
      setUser(response.user);
    } catch (err: any) {
      setError(err.message || 'Bejelentkezési hiba');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleRoleSwitch = async (newRole: 'manager' | 'employee') => {
    try {
      setLoading(true);
      console.log('Switching role to:', newRole);
      const response = await api.switchRole(newRole);
      console.log('Role switch response:', response);
      saveAuth(response.token, response.user);
      setUser(response.user);
    } catch (err: any) {
      setError(err.message || 'Szerepváltási hiba');
      console.error('Role switch error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = useCallback(() => {
    clearAuth();
    setUser(null);
    setError('');
  }, []);

  useIdleTimeout(handleLogout);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 border-4 border-sky-200 border-t-sky-500 rounded-full animate-spin"></div>
          <p className="text-gray-600 font-medium">Betöltés...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginForm onSubmit={handleLogin} isLoading={loading} error={error} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      <Header user={user} onLogout={handleLogout} onRoleSwitch={handleRoleSwitch} />
      {user.role === 'manager' ? (
        <ManagerDashboard />
      ) : (
        <EmployeeDashboard />
      )}
    </div>
  );
}

export default App;
