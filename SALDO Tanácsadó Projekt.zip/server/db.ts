import Database from 'better-sqlite3';
import { Kysely, SqliteDialect } from 'kysely';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.join(__dirname, '..', 'data');

interface UserTable {
  id: number;
  email: string;
  name: string;
  password: string;
  role: 'manager' | 'employee';
  created_at: string;
  monthly_planned_hours: number;
  is_admin: number;
}

interface ProjectTable {
  id: number;
  name: string;
  project_id: string | null;
  target_hours: number | null;
  assigned_to: number | null;
  is_completed: number;
  completed_at: string | null;
  created_at: string;
}

interface LogTable {
  id: number;
  user_id: number;
  project_id: number | null;
  date: string;
  hours: number;
  log_type: 'project' | 'vacation' | 'sick_leave' | 'article_writing' | 'presentation' | 'day_off' | 'other' | 'mandatory_training' | 'administration' | 'flat_rate_phone' | 'flat_rate_letter' | 'management_flat_rate' | 'management_expert' | 'management_other';
  comments: string | null;
  created_at: string;
}

interface GroupTable {
  id: number;
  name: string;
  type: 'employee' | 'project';
  created_at: string;
}

interface GroupMemberTable {
  id: number;
  group_id: number;
  member_id: number;
  created_at: string;
}

interface ProjectGroupTable {
  id: number;
  name: string;
  created_at: string;
}

interface ProjectGroupMemberTable {
  id: number;
  project_group_id: number;
  user_id: number;
  created_at: string;
}

interface UserScheduleTable {
  id: number;
  user_id: number;
  date: string;
  available_hours: number;
  created_at: string;
}

interface ProjectProjectGroupTable {
  id: number;
  project_id: number;
  project_group_id: number;
  created_at: string;
}

export interface Database {
  users: UserTable;
  projects: ProjectTable;
  logs: LogTable;
  groups: GroupTable;
  group_members: GroupMemberTable;
  project_groups: ProjectGroupTable;
  project_group_members: ProjectGroupMemberTable;
  user_schedules: UserScheduleTable;
  project_project_groups: ProjectProjectGroupTable;
}

const sqliteDb = new Database(path.join(dataDir, 'database.sqlite'));

export const db = new Kysely<Database>({
  dialect: new SqliteDialect({ database: sqliteDb }),
  log: ['query', 'error']
});
