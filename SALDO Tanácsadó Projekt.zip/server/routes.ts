import express from 'express';
import { db } from './db.js';
import { authMiddleware, requireManager, AuthRequest } from './auth.js';

export const router = express.Router();

// --- AUTH ROUTES ---

router.post('/api/auth/login', async (req: express.Request, res: express.Response) => {
  const { email, password } = req.body;

  if (!email || !password) {
    res.status(400).json({ error: 'Missing email or password' });
    return;
  }

  try {
    const user = await db
      .selectFrom('users')
      .where('email', '=', email)
      .where('password', '=', password)
      .selectAll()
      .executeTakeFirst();

    if (!user) {
      res.status(401).json({ error: 'Invalid credentials' });
      return;
    }

    const token = Buffer.from(JSON.stringify({ userId: user.id })).toString('base64');
    res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        is_admin: user.is_admin
      }
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Switch role (for users with admin rights)
router.post('/api/switch-role', authMiddleware, async (req: AuthRequest, res: express.Response) => {
  const { role } = req.body;

  if (!role || (role !== 'manager' && role !== 'employee')) {
    res.status(400).json({ error: 'Invalid role' });
    return;
  }

  try {
    const user = await db
      .selectFrom('users')
      .where('id', '=', req.user!.id)
      .selectAll()
      .executeTakeFirst();

    if (!user) {
      res.status(404).json({ error: 'User not found' });
      return;
    }

    // Check if user has admin rights
    if (user.is_admin !== 1) {
      res.status(403).json({ error: 'Not authorized to switch roles' });
      return;
    }

    const token = Buffer.from(JSON.stringify({ userId: user.id, effectiveRole: role })).toString('base64');
    res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: role,
        is_admin: user.is_admin,
        actualRole: user.role
      }
    });
  } catch (err) {
    console.error('Switch role error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// --- PROTECTED ROUTES ---

// Get current user
router.get('/api/user', authMiddleware, async (req: AuthRequest, res: express.Response) => {
  res.json(req.user);
});

// --- MANAGER ROUTES ---

// Create project
router.post('/api/projects', authMiddleware, requireManager, async (req: AuthRequest, res: express.Response) => {
  const { name, project_id, target_hours, project_group_ids } = req.body;

  if (!name || !project_id || !project_group_ids || project_group_ids.length === 0) {
    res.status(400).json({ error: 'Missing required fields' });
    return;
  }

  try {
    // Check if project_id already exists
    const existingProject = await db
      .selectFrom('projects')
      .where('project_id', '=', project_id)
      .selectAll()
      .executeTakeFirst();

    if (existingProject) {
      res.status(400).json({ error: 'Project ID already exists' });
      return;
    }

    const result = await db
      .insertInto('projects')
      .values({
        name,
        project_id,
        target_hours: target_hours !== null && target_hours !== undefined ? Number(target_hours) : null,
        assigned_to: null,
        is_completed: 0,
        created_at: new Date().toISOString()
      })
      .executeTakeFirstOrThrow();

    const projectId = Number(result.insertId);

    // Add project to selected groups
    if (project_group_ids.length > 0) {
      await db
        .insertInto('project_project_groups')
        .values(
          project_group_ids.map((groupId: number) => ({
            project_id: projectId,
            project_group_id: groupId,
            created_at: new Date().toISOString()
          }))
        )
        .execute();
    }

    res.json({ id: projectId });
  } catch (err) {
    console.error('Create project error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update project
router.put('/api/projects/:id', authMiddleware, requireManager, async (req: AuthRequest, res: express.Response) => {
  const { id } = req.params;
  const { name, target_hours, project_group_ids } = req.body;

  if (!name || !project_group_ids || project_group_ids.length === 0) {
    res.status(400).json({ error: 'Missing required fields' });
    return;
  }

  try {
    await db
      .updateTable('projects')
      .where('id', '=', Number(id))
      .set({
        name,
        target_hours: target_hours !== null && target_hours !== undefined ? Number(target_hours) : null,
        assigned_to: null
      })
      .execute();

    // Remove existing project group associations
    await db
      .deleteFrom('project_project_groups')
      .where('project_id', '=', Number(id))
      .execute();

    // Add new project group associations
    if (project_group_ids.length > 0) {
      await db
        .insertInto('project_project_groups')
        .values(
          project_group_ids.map((groupId: number) => ({
            project_id: Number(id),
            project_group_id: groupId,
            created_at: new Date().toISOString()
          }))
        )
        .execute();
    }

    res.json({ message: 'Project updated successfully' });
  } catch (err) {
    console.error('Update project error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete project
router.delete('/api/projects/:id', authMiddleware, requireManager, async (req: AuthRequest, res: express.Response) => {
  const { id } = req.params;

  try {
    // Delete all logs associated with the project first
    await db
      .deleteFrom('logs')
      .where('project_id', '=', Number(id))
      .execute();

    // Then delete the project
    await db
      .deleteFrom('projects')
      .where('id', '=', Number(id))
      .execute();

    res.json({ message: 'Project deleted successfully' });
  } catch (err) {
    console.error('Delete project error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get all projects with logs summary
router.get('/api/projects', authMiddleware, requireManager, async (req: AuthRequest, res: express.Response) => {
  try {
    const projects = await db
      .selectFrom('projects')
      .selectAll()
      .execute();

    const projectsWithLogs = await Promise.all(
      projects.map(async (project) => {
        const totalHours = await db
          .selectFrom('logs')
          .where('project_id', '=', project.id)
          .select(db.fn.sum('hours').as('total'))
          .executeTakeFirst();

        const employeeLogs = await db
          .selectFrom('logs')
          .innerJoin('users', 'logs.user_id', 'users.id')
          .where('logs.project_id', '=', project.id)
          .select([
            'users.id as user_id',
            'users.name as user_name',
            'users.email as user_email',
            db.fn.sum('logs.hours').as('total_hours')
          ])
          .groupBy(['users.id', 'users.name', 'users.email'])
          .execute();

        let assignee = null;
        if (project.assigned_to) {
          assignee = await db
            .selectFrom('users')
            .where('id', '=', project.assigned_to)
            .select(['email', 'name'])
            .executeTakeFirst();
        }

        // Get project groups
        const projectGroups = await db
          .selectFrom('project_project_groups')
          .innerJoin('project_groups', 'project_project_groups.project_group_id', 'project_groups.id')
          .where('project_project_groups.project_id', '=', project.id)
          .select(['project_groups.id', 'project_groups.name'])
          .execute();

        return {
          ...project,
          actual_hours: totalHours?.total || 0,
          assigned_email: assignee?.email || '',
          assigned_name: assignee?.name || assignee?.email || '',
          employee_logs: employeeLogs.map(log => ({
            user_id: log.user_id,
            user_name: log.user_name || log.user_email,
            total_hours: log.total_hours || 0
          })),
          project_groups: projectGroups.map(g => ({ id: g.id, name: g.name }))
        };
      })
    );

    res.json(projectsWithLogs);
  } catch (err) {
    console.error('Get projects error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get all employees
router.get('/api/employees', authMiddleware, requireManager, async (req: AuthRequest, res: express.Response) => {
  try {
    const employees = await db
      .selectFrom('users')
      .where('role', '=', 'employee')
      .select(['id', 'email', 'name', 'monthly_planned_hours', 'is_admin'])
      .execute();

    res.json(employees);
  } catch (err) {
    console.error('Get employees error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create employee
router.post('/api/employees', authMiddleware, requireManager, async (req: AuthRequest, res: express.Response) => {
  const { email, name } = req.body;

  if (!email) {
    res.status(400).json({ error: 'Missing email' });
    return;
  }

  try {
    await db
      .insertInto('users')
      .values({
        email,
        name: name || '',
        password: '1234',
        role: 'employee',
        created_at: new Date().toISOString()
      })
      .executeTakeFirstOrThrow();

    res.json({ message: 'Employee added successfully' });
  } catch (err: any) {
    console.error('Create employee error:', err);
    if (err.message?.includes('UNIQUE')) {
      res.status(400).json({ error: 'Email already exists' });
      return;
    }
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Reset employee password
router.post('/api/employees/:id/reset-password', authMiddleware, requireManager, async (req: AuthRequest, res: express.Response) => {
  const { id } = req.params;

  try {
    await db
      .updateTable('users')
      .where('id', '=', Number(id))
      .set({ password: '1234' })
      .execute();

    res.json({ message: 'Password reset to 1234' });
  } catch (err) {
    console.error('Reset password error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update employee
router.put('/api/employees/:id', authMiddleware, requireManager, async (req: AuthRequest, res: express.Response) => {
  const { id } = req.params;
  const { email, name, monthly_planned_hours, is_admin } = req.body;

  if (!email) {
    res.status(400).json({ error: 'Missing email' });
    return;
  }

  try {
    const updateData: any = { email, name: name || '' };
    
    if (monthly_planned_hours !== undefined && monthly_planned_hours !== null) {
      updateData.monthly_planned_hours = Number(monthly_planned_hours);
    }

    if (is_admin !== undefined) {
      updateData.is_admin = is_admin ? 1 : 0;
    }

    await db
      .updateTable('users')
      .where('id', '=', Number(id))
      .set(updateData)
      .execute();

    res.json({ message: 'Employee updated successfully' });
  } catch (err: any) {
    console.error('Update employee error:', err);
    if (err.message?.includes('UNIQUE')) {
      res.status(400).json({ error: 'Email already exists' });
      return;
    }
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete employee
router.delete('/api/employees/:id', authMiddleware, requireManager, async (req: AuthRequest, res: express.Response) => {
  const { id } = req.params;

  try {
    // Delete all logs associated with the employee first
    await db
      .deleteFrom('logs')
      .where('user_id', '=', Number(id))
      .execute();

    // Delete the employee
    await db
      .deleteFrom('users')
      .where('id', '=', Number(id))
      .execute();

    res.json({ message: 'Employee deleted successfully' });
  } catch (err) {
    console.error('Delete employee error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get statistics
router.get('/api/statistics', authMiddleware, requireManager, async (req: AuthRequest, res: express.Response) => {
  try {
    const projects = await db
      .selectFrom('projects')
      .selectAll()
      .execute();

    const stats = await Promise.all(
      projects.map(async (project) => {
        const logs = await db
          .selectFrom('logs')
          .where('project_id', '=', project.id)
          .selectAll()
          .execute();

        const totalHours = logs.reduce((sum, log) => sum + log.hours, 0);

        return {
          id: project.id,
          name: project.name,
          target_hours: project.target_hours,
          actual_hours: totalHours,
          progress: totalHours / project.target_hours,
          remaining: Math.max(0, project.target_hours - totalHours),
          logs
        };
      })
    );

    res.json(stats);
  } catch (err) {
    console.error('Get statistics error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// --- EMPLOYEE ROUTES ---

// Get my projects (all projects in my project groups)
router.get('/api/my-projects', authMiddleware, async (req: AuthRequest, res: express.Response) => {
  try {
    // Get user's project groups
    const userProjectGroups = await db
      .selectFrom('project_group_members')
      .where('user_id', '=', req.user!.id)
      .select(['project_group_id'])
      .execute();

    if (userProjectGroups.length === 0) {
      res.json([]);
      return;
    }

    const groupIds = userProjectGroups.map(g => g.project_group_id);

    // Get all projects in these groups via junction table
    const projectsInGroups = await db
      .selectFrom('project_project_groups')
      .innerJoin('projects', 'project_project_groups.project_id', 'projects.id')
      .where('project_project_groups.project_group_id', 'in', groupIds)
      .select(['projects.id', 'projects.name', 'projects.target_hours'])
      .execute();

    // Deduplicate projects (a project may appear in multiple groups)
    const uniqueProjects = Array.from(
      new Map(projectsInGroups.map(p => [p.id, p])).values()
    );

    // For each project, get all employees who logged hours
    const projectsWithLogs = await Promise.all(
      uniqueProjects.map(async (project) => {
        const employeeLogs = await db
          .selectFrom('logs')
          .innerJoin('users', 'logs.user_id', 'users.id')
          .where('logs.project_id', '=', project.id)
          .select([
            'users.id as user_id',
            'users.name as user_name',
            'users.email as user_email',
            db.fn.sum('logs.hours').as('total_hours')
          ])
          .groupBy(['users.id', 'users.name', 'users.email'])
          .execute();

        // Get project groups
        const projectGroups = await db
          .selectFrom('project_project_groups')
          .innerJoin('project_groups', 'project_project_groups.project_group_id', 'project_groups.id')
          .where('project_project_groups.project_id', '=', project.id)
          .select(['project_groups.id', 'project_groups.name'])
          .execute();

        return {
          ...project,
          employee_logs: employeeLogs.map(log => ({
            user_id: log.user_id,
            user_name: log.user_name || log.user_email,
            total_hours: log.total_hours || 0
          })),
          project_groups: projectGroups.map(g => ({ id: g.id, name: g.name }))
        };
      })
    );

    res.json(projectsWithLogs);
  } catch (err) {
    console.error('Get my projects error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Log work hours
router.post('/api/logs', authMiddleware, async (req: AuthRequest, res: express.Response) => {
  const { project_id, date, hours, log_type = 'project', comments } = req.body;

  if (!date || !hours || !log_type) {
    res.status(400).json({ error: 'Missing required fields' });
    return;
  }

  // Validate that project_id is provided for project type logs
  if (log_type === 'project' && !project_id) {
    res.status(400).json({ error: 'Project ID is required for project logs' });
    return;
  }

  try {
    await db
      .insertInto('logs')
      .values({
        user_id: req.user!.id,
        project_id: project_id ? Number(project_id) : null,
        date,
        hours: Number(hours),
        log_type,
        comments: comments || null,
        created_at: new Date().toISOString()
      })
      .executeTakeFirstOrThrow();

    res.json({ message: 'Hours logged successfully' });
  } catch (err) {
    console.error('Log hours error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get logs for a date
router.get('/api/logs/:date', authMiddleware, async (req: AuthRequest, res: express.Response) => {
  const { date } = req.params;

  try {
    const logs = await db
      .selectFrom('logs')
      .leftJoin('projects', 'logs.project_id', 'projects.id')
      .where('logs.user_id', '=', req.user!.id)
      .where('logs.date', '=', date)
      .select([
        'logs.id',
        'logs.project_id',
        'logs.hours',
        'logs.log_type',
        'logs.comments',
        'projects.name as project_name'
      ])
      .execute();

    const totalHours = logs.reduce((sum, log) => sum + log.hours, 0);

    res.json({ logs, totalHours });
  } catch (err) {
    console.error('Get logs error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get all logs with project info (for employee logs table)
router.get('/api/all-logs', authMiddleware, async (req: AuthRequest, res: express.Response) => {
  const { startDate, endDate, projectId } = req.query;

  try {
    let query = db
      .selectFrom('logs')
      .leftJoin('projects', 'logs.project_id', 'projects.id')
      .where('logs.user_id', '=', req.user!.id)
      .select([
        'logs.id',
        'logs.date',
        'logs.hours',
        'logs.project_id',
        'logs.log_type',
        'logs.comments',
        'projects.name as project_name'
      ]);

    if (startDate) {
      query = query.where('logs.date', '>=', startDate as string);
    }

    if (endDate) {
      query = query.where('logs.date', '<=', endDate as string);
    }

    if (projectId) {
      query = query.where('logs.project_id', '=', Number(projectId));
    }

    const logs = await query.orderBy('logs.date', 'desc').execute();

    res.json(logs);
  } catch (err) {
    console.error('Get all logs error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update log
router.put('/api/logs/:id', authMiddleware, async (req: AuthRequest, res: express.Response) => {
  const { id } = req.params;
  const { hours } = req.body;

  if (!hours) {
    res.status(400).json({ error: 'Missing hours' });
    return;
  }

  try {
    // Verify user owns this log
    const log = await db
      .selectFrom('logs')
      .where('id', '=', Number(id))
      .where('user_id', '=', req.user!.id)
      .selectAll()
      .executeTakeFirst();

    if (!log) {
      res.status(404).json({ error: 'Log not found' });
      return;
    }

    await db
      .updateTable('logs')
      .where('id', '=', Number(id))
      .set({ hours: Number(hours) })
      .execute();

    res.json({ message: 'Log updated successfully' });
  } catch (err) {
    console.error('Update log error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete log
router.delete('/api/logs/:id', authMiddleware, async (req: AuthRequest, res: express.Response) => {
  const { id } = req.params;

  try {
    // Verify user owns this log
    const log = await db
      .selectFrom('logs')
      .where('id', '=', Number(id))
      .where('user_id', '=', req.user!.id)
      .selectAll()
      .executeTakeFirst();

    if (!log) {
      res.status(404).json({ error: 'Log not found' });
      return;
    }

    await db
      .deleteFrom('logs')
      .where('id', '=', Number(id))
      .execute();

    res.json({ message: 'Log deleted successfully' });
  } catch (err) {
    console.error('Delete log error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Change password
router.post('/api/change-password', authMiddleware, async (req: AuthRequest, res: express.Response) => {
  const { oldPassword, newPassword } = req.body;

  if (!oldPassword || !newPassword) {
    res.status(400).json({ error: 'Missing password fields' });
    return;
  }

  try {
    const user = await db
      .selectFrom('users')
      .where('id', '=', req.user!.id)
      .where('password', '=', oldPassword)
      .selectAll()
      .executeTakeFirst();

    if (!user) {
      res.status(401).json({ error: 'Old password is incorrect' });
      return;
    }

    await db
      .updateTable('users')
      .where('id', '=', req.user!.id)
      .set({ password: newPassword })
      .execute();

    res.json({ message: 'Password changed successfully' });
  } catch (err) {
    console.error('Change password error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// --- GROUP ROUTES (MANAGER) ---

// Get all groups
router.get('/api/groups', authMiddleware, requireManager, async (req: AuthRequest, res: express.Response) => {
  try {
    const groups = await db
      .selectFrom('groups')
      .selectAll()
      .execute();

    const groupsWithMembers = await Promise.all(
      groups.map(async (group) => {
        const members = await db
          .selectFrom('group_members')
          .where('group_id', '=', group.id)
          .select(['member_id'])
          .execute();

        return {
          ...group,
          member_ids: members.map(m => m.member_id)
        };
      })
    );

    res.json(groupsWithMembers);
  } catch (err) {
    console.error('Get groups error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create group
router.post('/api/groups', authMiddleware, requireManager, async (req: AuthRequest, res: express.Response) => {
  const { name, type, member_ids } = req.body;

  if (!name || !type || !member_ids) {
    res.status(400).json({ error: 'Missing required fields' });
    return;
  }

  try {
    const result = await db
      .insertInto('groups')
      .values({
        name,
        type,
        created_at: new Date().toISOString()
      })
      .executeTakeFirstOrThrow();

    const groupId = Number(result.insertId);

    // Add members
    if (member_ids.length > 0) {
      await db
        .insertInto('group_members')
        .values(
          member_ids.map((memberId: number) => ({
            group_id: groupId,
            member_id: memberId,
            created_at: new Date().toISOString()
          }))
        )
        .execute();
    }

    res.json({ id: groupId });
  } catch (err) {
    console.error('Create group error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update group
router.put('/api/groups/:id', authMiddleware, requireManager, async (req: AuthRequest, res: express.Response) => {
  const { id } = req.params;
  const { name, member_ids } = req.body;

  if (!name || !member_ids) {
    res.status(400).json({ error: 'Missing required fields' });
    return;
  }

  try {
    await db
      .updateTable('groups')
      .where('id', '=', Number(id))
      .set({ name })
      .execute();

    // Remove all existing members
    await db
      .deleteFrom('group_members')
      .where('group_id', '=', Number(id))
      .execute();

    // Add new members
    if (member_ids.length > 0) {
      await db
        .insertInto('group_members')
        .values(
          member_ids.map((memberId: number) => ({
            group_id: Number(id),
            member_id: memberId,
            created_at: new Date().toISOString()
          }))
        )
        .execute();
    }

    res.json({ message: 'Group updated successfully' });
  } catch (err) {
    console.error('Update group error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete group
router.delete('/api/groups/:id', authMiddleware, requireManager, async (req: AuthRequest, res: express.Response) => {
  const { id } = req.params;

  try {
    await db
      .deleteFrom('groups')
      .where('id', '=', Number(id))
      .execute();

    res.json({ message: 'Group deleted successfully' });
  } catch (err) {
    console.error('Delete group error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// --- PROJECT GROUPS ROUTES (MANAGER) ---

// Get all project groups with members
router.get('/api/project-groups', authMiddleware, requireManager, async (req: AuthRequest, res: express.Response) => {
  try {
    const groups = await db
      .selectFrom('project_groups')
      .selectAll()
      .orderBy('name', 'asc')
      .execute();

    const groupsWithMembers = await Promise.all(
      groups.map(async (group) => {
        const members = await db
          .selectFrom('project_group_members')
          .where('project_group_id', '=', group.id)
          .select(['user_id'])
          .execute();

        return {
          ...group,
          member_ids: members.map(m => m.user_id)
        };
      })
    );

    res.json(groupsWithMembers);
  } catch (err) {
    console.error('Get project groups error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create project group
router.post('/api/project-groups', authMiddleware, requireManager, async (req: AuthRequest, res: express.Response) => {
  const { name, member_ids } = req.body;

  if (!name) {
    res.status(400).json({ error: 'Missing group name' });
    return;
  }

  try {
    const result = await db
      .insertInto('project_groups')
      .values({
        name,
        created_at: new Date().toISOString()
      })
      .executeTakeFirstOrThrow();

    const groupId = Number(result.insertId);

    // Add members if provided
    if (member_ids && member_ids.length > 0) {
      await db
        .insertInto('project_group_members')
        .values(
          member_ids.map((userId: number) => ({
            project_group_id: groupId,
            user_id: userId,
            created_at: new Date().toISOString()
          }))
        )
        .execute();
    }

    res.json({ id: groupId });
  } catch (err: any) {
    console.error('Create project group error:', err);
    if (err.message?.includes('UNIQUE')) {
      res.status(400).json({ error: 'Project group name already exists' });
      return;
    }
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update project group
router.put('/api/project-groups/:id', authMiddleware, requireManager, async (req: AuthRequest, res: express.Response) => {
  const { id } = req.params;
  const { name, member_ids } = req.body;

  if (!name) {
    res.status(400).json({ error: 'Missing group name' });
    return;
  }

  try {
    await db
      .updateTable('project_groups')
      .where('id', '=', Number(id))
      .set({ name })
      .execute();

    // Remove all existing members
    await db
      .deleteFrom('project_group_members')
      .where('project_group_id', '=', Number(id))
      .execute();

    // Add new members
    if (member_ids && member_ids.length > 0) {
      await db
        .insertInto('project_group_members')
        .values(
          member_ids.map((userId: number) => ({
            project_group_id: Number(id),
            user_id: userId,
            created_at: new Date().toISOString()
          }))
        )
        .execute();
    }

    res.json({ message: 'Project group updated successfully' });
  } catch (err: any) {
    console.error('Update project group error:', err);
    if (err.message?.includes('UNIQUE')) {
      res.status(400).json({ error: 'Project group name already exists' });
      return;
    }
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete project group
router.delete('/api/project-groups/:id', authMiddleware, requireManager, async (req: AuthRequest, res: express.Response) => {
  const { id } = req.params;

  try {
    // Delete associations in junction table (CASCADE will handle this automatically, but being explicit)
    await db
      .deleteFrom('project_project_groups')
      .where('project_group_id', '=', Number(id))
      .execute();

    // Delete the group
    await db
      .deleteFrom('project_groups')
      .where('id', '=', Number(id))
      .execute();

    res.json({ message: 'Project group deleted successfully' });
  } catch (err) {
    console.error('Delete project group error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get monthly summary (employee)
router.get('/api/monthly-summary/:month', authMiddleware, async (req: AuthRequest, res: express.Response) => {
  const { month } = req.params; // Format: YYYY-MM

  try {
    // Get user info to check for monthly_planned_hours
    const user = await db
      .selectFrom('users')
      .where('id', '=', req.user!.id)
      .select(['monthly_planned_hours'])
      .executeTakeFirst();

    // Helper function to calculate available hours based on day of week
    const getAvailableHours = (dateString: string): number => {
      const date = new Date(dateString);
      const dayOfWeek = date.getDay(); // 0 = Sunday, 1 = Monday, ..., 5 = Friday, 6 = Saturday
      
      if (dayOfWeek >= 1 && dayOfWeek <= 4) {
        // Monday to Thursday
        return 8.5;
      } else if (dayOfWeek === 5) {
        // Friday
        return 6;
      } else {
        // Weekend
        return 0;
      }
    };

    // Get all logs for the user in the selected month
    const logs = await db
      .selectFrom('logs')
      .where('user_id', '=', req.user!.id)
      .where('date', 'like', `${month}%`)
      .select(['date', db.fn.sum('hours').as('total_hours')])
      .groupBy('date')
      .orderBy('date', 'asc')
      .execute();

    // Add available hours to each log
    const logsWithSchedule = logs.map(log => ({
      ...log,
      available_hours: getAvailableHours(log.date)
    }));

    // Calculate total available hours for the month
    let totalAvailable = 0;

    if (user?.monthly_planned_hours !== null && user?.monthly_planned_hours !== undefined) {
      // Use manually set monthly planned hours for part-time employees
      totalAvailable = user.monthly_planned_hours;
    } else {
      // Calculate based on standard work schedule
      const [year, monthNum] = month.split('-').map(Number);
      const daysInMonth = new Date(year, monthNum, 0).getDate();
      
      for (let day = 1; day <= daysInMonth; day++) {
        const dateStr = `${year}-${String(monthNum).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        totalAvailable += getAvailableHours(dateStr);
      }
    }

    res.json({ 
      logs: logsWithSchedule,
      total_available_hours: totalAvailable
    });
  } catch (err) {
    console.error('Get monthly summary error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get statistics with groups
router.get('/api/statistics-grouped', authMiddleware, requireManager, async (req: AuthRequest, res: express.Response) => {
  const { groupId } = req.query;

  try {
    let projectIds: number[] = [];

    if (groupId) {
      // Get projects from group
      const members = await db
        .selectFrom('group_members')
        .where('group_id', '=', Number(groupId))
        .select(['member_id'])
        .execute();

      projectIds = members.map(m => m.member_id);
    }

    let query = db.selectFrom('projects').selectAll();

    if (projectIds.length > 0) {
      query = query.where('id', 'in', projectIds);
    }

    const projects = await query.execute();

    const stats = await Promise.all(
      projects.map(async (project) => {
        const logs = await db
          .selectFrom('logs')
          .where('project_id', '=', project.id)
          .selectAll()
          .execute();

        const totalHours = logs.reduce((sum, log) => sum + log.hours, 0);

        return {
          id: project.id,
          name: project.name,
          target_hours: project.target_hours,
          actual_hours: totalHours,
          progress: totalHours / project.target_hours,
          remaining: Math.max(0, project.target_hours - totalHours),
          logs
        };
      })
    );

    res.json(stats);
  } catch (err) {
    console.error('Get grouped statistics error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Close project
router.post('/api/projects/:id/close', authMiddleware, async (req: AuthRequest, res: express.Response) => {
  const { id } = req.params;

  try {
    const now = new Date().toISOString();
    
    await db
      .updateTable('projects')
      .where('id', '=', Number(id))
      .set({ 
        is_completed: 1,
        completed_at: now
      })
      .execute();

    res.json({ message: 'Project closed successfully' });
  } catch (err) {
    console.error('Close project error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Reopen project
router.post('/api/projects/:id/reopen', authMiddleware, async (req: AuthRequest, res: express.Response) => {
  const { id } = req.params;

  try {
    await db
      .updateTable('projects')
      .where('id', '=', Number(id))
      .set({ 
        is_completed: 0,
        completed_at: null
      })
      .execute();

    res.json({ message: 'Project reopened successfully' });
  } catch (err) {
    console.error('Reopen project error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Import multiple projects
router.post('/api/projects/import', authMiddleware, requireManager, async (req: AuthRequest, res: express.Response) => {
  const { projects } = req.body;

  if (!projects || !Array.isArray(projects)) {
    res.status(400).json({ error: 'Invalid projects data' });
    return;
  }

  try {
    const createdIds: number[] = [];

    for (const project of projects) {
      const { name, project_id, target_hours, project_group_ids } = project;

      if (!name || !project_id || !project_group_ids || project_group_ids.length === 0) {
        console.warn(`Skipping invalid project: ${name}`);
        continue;
      }

      const result = await db
        .insertInto('projects')
        .values({
          name,
          project_id,
          target_hours: target_hours !== null && target_hours !== undefined ? Number(target_hours) : null,
          assigned_to: null,
          is_completed: 0,
          created_at: new Date().toISOString()
        })
        .executeTakeFirstOrThrow();

      const projectId = Number(result.insertId);

      // Add project to selected groups
      if (project_group_ids.length > 0) {
        await db
          .insertInto('project_project_groups')
          .values(
            project_group_ids.map((groupId: number) => ({
              project_id: projectId,
              project_group_id: groupId,
              created_at: new Date().toISOString()
            }))
          )
          .execute();
      }

      createdIds.push(projectId);
    }

    res.json({ 
      message: `Successfully imported ${createdIds.length} projects`,
      created_ids: createdIds
    });
  } catch (err) {
    console.error('Import projects error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get employee projects summary with hours
router.get('/api/employee-projects', authMiddleware, requireManager, async (req: AuthRequest, res: express.Response) => {
  try {
    const employees = await db
      .selectFrom('users')
      .where('role', '=', 'employee')
      .select(['id', 'name', 'email'])
      .execute();

    const result = await Promise.all(
      employees.map(async (employee) => {
        // Get all projects the employee has logged hours for, only if target_hours is set
        const projectsWithHours = await db
          .selectFrom('logs')
          .innerJoin('projects', 'logs.project_id', 'projects.id')
          .where('logs.user_id', '=', employee.id)
          .where('projects.target_hours', 'is not', null)
          .select([
            'projects.id',
            'projects.name',
            'projects.target_hours',
            'projects.is_completed',
            db.fn.sum('logs.hours').as('actual_hours')
          ])
          .groupBy(['projects.id', 'projects.name', 'projects.target_hours', 'projects.is_completed'])
          .execute();

        return {
          employee_id: employee.id,
          employee_name: employee.name || employee.email,
          projects: projectsWithHours.map(p => ({
            id: p.id,
            name: p.name,
            target_hours: p.target_hours || 0,
            actual_hours: p.actual_hours || 0,
            is_completed: p.is_completed
          }))
        };
      })
    );

    res.json(result);
  } catch (err) {
    console.error('Get employee projects error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get employee monthly summary (Manager)
router.get('/api/employees/:employeeId/monthly-summary/:month', authMiddleware, requireManager, async (req: AuthRequest, res: express.Response) => {
  const { employeeId, month } = req.params;

  try {
    // Get user info to check for monthly_planned_hours
    const user = await db
      .selectFrom('users')
      .where('id', '=', Number(employeeId))
      .select(['monthly_planned_hours'])
      .executeTakeFirst();

    // Helper function to calculate available hours based on day of week
    const getAvailableHours = (dateString: string): number => {
      const date = new Date(dateString);
      const dayOfWeek = date.getDay();
      
      if (dayOfWeek >= 1 && dayOfWeek <= 4) {
        return 8.5;
      } else if (dayOfWeek === 5) {
        return 6;
      } else {
        return 0;
      }
    };

    // Get all logs for the employee in the selected month
    const logs = await db
      .selectFrom('logs')
      .where('user_id', '=', Number(employeeId))
      .where('date', 'like', `${month}%`)
      .select(['date', db.fn.sum('hours').as('total_hours')])
      .groupBy('date')
      .orderBy('date', 'asc')
      .execute();

    // Add available hours to each log
    const logsWithSchedule = logs.map(log => ({
      ...log,
      available_hours: getAvailableHours(log.date)
    }));

    // Calculate total available hours for the month
    let totalAvailable = 0;

    if (user?.monthly_planned_hours !== null && user?.monthly_planned_hours !== undefined) {
      totalAvailable = user.monthly_planned_hours;
    } else {
      const [year, monthNum] = month.split('-').map(Number);
      const daysInMonth = new Date(year, monthNum, 0).getDate();
      
      for (let day = 1; day <= daysInMonth; day++) {
        const dateStr = `${year}-${String(monthNum).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        totalAvailable += getAvailableHours(dateStr);
      }
    }

    res.json({ 
      logs: logsWithSchedule,
      total_available_hours: totalAvailable
    });
  } catch (err) {
    console.error('Get employee monthly summary error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get employee all logs (Manager)
router.get('/api/employees/:employeeId/all-logs', authMiddleware, requireManager, async (req: AuthRequest, res: express.Response) => {
  const { employeeId } = req.params;
  const { startDate, endDate, projectId } = req.query;

  try {
    let query = db
      .selectFrom('logs')
      .leftJoin('projects', 'logs.project_id', 'projects.id')
      .where('logs.user_id', '=', Number(employeeId))
      .select([
        'logs.id',
        'logs.date',
        'logs.hours',
        'logs.project_id',
        'logs.log_type',
        'logs.comments',
        'projects.name as project_name'
      ]);

    if (startDate) {
      query = query.where('logs.date', '>=', startDate as string);
    }

    if (endDate) {
      query = query.where('logs.date', '<=', endDate as string);
    }

    if (projectId) {
      query = query.where('logs.project_id', '=', Number(projectId));
    }

    const logs = await query.orderBy('logs.date', 'asc').execute();

    res.json(logs);
  } catch (err) {
    console.error('Get employee all logs error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Import multiple project groups
router.post('/api/project-groups/import', authMiddleware, requireManager, async (req: AuthRequest, res: express.Response) => {
  const { groups } = req.body;

  if (!groups || !Array.isArray(groups)) {
    res.status(400).json({ error: 'Invalid groups data' });
    return;
  }

  try {
    const createdIds: number[] = [];

    for (const group of groups) {
      const { name, member_emails } = group;

      if (!name) {
        console.warn(`Skipping invalid group: ${name}`);
        continue;
      }

      // Check if group already exists
      const existingGroup = await db
        .selectFrom('project_groups')
        .where('name', '=', name)
        .selectAll()
        .executeTakeFirst();

      let groupId: number;

      if (existingGroup) {
        groupId = existingGroup.id;
        console.log(`Group "${name}" already exists, updating members`);
      } else {
        const result = await db
          .insertInto('project_groups')
          .values({
            name,
            created_at: new Date().toISOString()
          })
          .executeTakeFirstOrThrow();

        groupId = Number(result.insertId);
        createdIds.push(groupId);
      }

      // Find members by email
      if (member_emails && member_emails.length > 0) {
        const users = await db
          .selectFrom('users')
          .where('email', 'in', member_emails)
          .select(['id'])
          .execute();

        const userIds = users.map(u => u.id);

        if (userIds.length > 0) {
          // Remove existing members
          await db
            .deleteFrom('project_group_members')
            .where('project_group_id', '=', groupId)
            .execute();

          // Add new members
          await db
            .insertInto('project_group_members')
            .values(
              userIds.map((userId: number) => ({
                project_group_id: groupId,
                user_id: userId,
                created_at: new Date().toISOString()
              }))
            )
            .execute();
        }
      }
    }

    res.json({ 
      message: `Successfully imported ${createdIds.length} project groups`,
      created_ids: createdIds
    });
  } catch (err) {
    console.error('Import project groups error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});
