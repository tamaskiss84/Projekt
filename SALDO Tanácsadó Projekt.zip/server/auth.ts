import express from 'express';
import { db } from './db.js';

export interface AuthRequest extends express.Request {
  user?: {
    id: number;
    email: string;
    role: 'manager' | 'employee';
  };
}

export const authMiddleware = async (req: AuthRequest, res: express.Response, next: express.NextFunction) => {
  const sessionToken = req.headers.authorization?.replace('Bearer ', '');
  
  if (!sessionToken || sessionToken.length < 10) {
    res.status(401).json({ error: 'Unauthorized' });
    return;
  }

   try {
     // Decode base64 token
     let decoded: string;
     try {
       // Validate base64 format before decoding
       if (!/^[A-Za-z0-9+/=]+$/.test(sessionToken)) {
         console.error('Auth error: Invalid token format (not base64)');
         res.status(401).json({ error: 'Unauthorized' });
         return;
       }
       decoded = Buffer.from(sessionToken, 'base64').toString('utf8');
     } catch (decodeErr) {
       console.error('Auth error: Failed to decode token:', decodeErr);
       res.status(401).json({ error: 'Unauthorized' });
       return;
     }
     
     // Validate that it's valid JSON
     if (!decoded || decoded.trim().length === 0) {
       console.error('Auth error: Empty decoded token');
       res.status(401).json({ error: 'Unauthorized' });
       return;
     }

     let session: any;
     try {
       session = JSON.parse(decoded);
     } catch (parseErr) {
       console.error('Auth error: Failed to parse token JSON. Decoded:', decoded.substring(0, 50));
       res.status(401).json({ error: 'Unauthorized' });
       return;
     }
    
    // Validate session structure
    if (!session || typeof session.userId !== 'number') {
      console.error('Auth error: Invalid session structure');
      res.status(401).json({ error: 'Unauthorized' });
      return;
    }

    const user = await db.selectFrom('users').where('id', '=', session.userId).selectAll().executeTakeFirst();
    
    if (!user) {
      console.error('Auth error: User not found for session');
      res.status(401).json({ error: 'Unauthorized' });
      return;
    }

    // Use effectiveRole if present (for users who switched roles)
    const effectiveRole = session.effectiveRole || user.role;

    req.user = {
      id: user.id,
      email: user.email,
      role: effectiveRole
    };

    next();
  } catch (err) {
    console.error('Auth error:', err);
    res.status(401).json({ error: 'Unauthorized' });
    return;
  }
};

export const requireManager = (req: AuthRequest, res: express.Response, next: express.NextFunction) => {
  if (!req.user || req.user.role !== 'manager') {
    res.status(403).json({ error: 'Forbidden' });
    return;
  }
  next();
};
