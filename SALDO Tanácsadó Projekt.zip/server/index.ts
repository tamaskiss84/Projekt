import express from 'express';
import dotenv from 'dotenv';
import { setupStaticServing } from './static-serve.js';
import { router } from './routes.js';
import { db } from './db.js';

dotenv.config();

const app = express();

// CORS middleware
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
    return;
  }
  
  next();
});

// Body parsing middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Initialize database with test data
async function initDatabase() {
  try {
    // Check if admin user exists
    const adminExists = await db
      .selectFrom('users')
      .where('email', '=', 'admin@ceg.hu')
      .selectAll()
      .executeTakeFirst();

    if (!adminExists) {
      console.log('Creating admin user...');
      await db
        .insertInto('users')
        .values({
          email: 'admin@ceg.hu',
          password: 'admin123',
          role: 'manager',
          created_at: new Date().toISOString()
        })
        .executeTakeFirstOrThrow();
      console.log('Admin user created successfully');
    }
  } catch (err) {
    console.error('Database initialization error:', err);
  }
}

// Routes
app.use(router);

// Export a function to start the server
export async function startServer(port) {
  try {
    await initDatabase();
    if (process.env.NODE_ENV === 'production') {
      setupStaticServing(app);
    }
    app.listen(port, () => {
      console.log(`API Server running on port ${port}`);
    });
  } catch (err) {
    console.error('Failed to start server:', err);
    process.exit(1);
  }
}

// Start the server directly if this is the main module
if (import.meta.url === `file://${process.argv[1]}`) {
  console.log('Starting server...');
  startServer(process.env.PORT || 3001);
}
